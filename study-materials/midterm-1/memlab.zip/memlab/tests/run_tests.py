"""Dependency-free test runner:  python tests/run_tests.py"""
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_all  # noqa: E402

tests = [(n, getattr(test_all, n)) for n in dir(test_all) if n.startswith("test_")]
failed = 0
t0 = time.time()
for name, fn in tests:
    try:
        fn()
        print("PASS", name)
    except Exception:
        failed += 1
        print("FAIL", name)
        traceback.print_exc()
print(f"\n{len(tests) - failed}/{len(tests)} tests passed in {time.time() - t0:.1f}s")
raise SystemExit(1 if failed else 0)
