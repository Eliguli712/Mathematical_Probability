"""Checks against the handwritten answers, closed forms, and brute-force enumeration.

Run with `python tests/run_tests.py` (no dependencies beyond numpy) or `pytest -q`."""
import math
import sys
from collections import Counter
from fractions import Fraction as F
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import embeddings as em  # noqa: E402
import hmm as H  # noqa: E402
import markov as mk  # noqa: E402
import memory as mem  # noqa: E402
import pipeline  # noqa: E402
from homework import ALPHABET, SYMBOLS, WORDS, X, Y  # noqa: E402
from markov import BOS, EOS, pad  # noqa: E402
from naive_bayes import BernoulliNB, all_states, empirical_cells  # noqa: E402

SENTS, LABELS = pipeline.load_corpus()
VOCAB = sorted({w for s in SENTS for w in s})

# P(S | x) for the 16 inputs as listed in the earlier discussion (4 decimals).
QUOTED_TABLE = {
    "0000": 0.6000, "0001": 0.0857, "0010": 0.6000, "0011": 0.0857,
    "0100": 0.4000, "0101": 0.0400, "0110": 0.4000, "0111": 0.0400,
    "1000": 0.9600, "1001": 0.6000, "1010": 0.9600, "1011": 0.6000,
    "1100": 0.9143, "1101": 0.4000, "1110": 0.9143, "1111": 0.4000,
}


# ---------- problem 5 ------------------------------------------------------
def test_hw5_parameters_match_handwritten_values():
    nb = BernoulliNB().fit(X, Y)
    assert nb.prior[1] == F(1, 2)
    assert nb.p[1] == [F(4, 5), F(2, 5), F(2, 5), F(1, 5)]
    assert nb.p[0] == [F(1, 5), F(3, 5), F(2, 5), F(4, 5)]


def test_hw5_answers_b_and_c():
    nb = BernoulliNB().fit(X, Y)
    assert nb.weight((0, 0, 1, 1), 1) == F(3, 625) and nb.weight((0, 0, 1, 1), 0) == F(32, 625)
    assert nb.posterior((0, 0, 1, 1)) == F(3, 35) and nb.predict((0, 0, 1, 1)) == 0
    assert nb.posterior((0, 1, 1, 0)) == F(2, 5) and nb.predict((0, 1, 1, 0)) == 0
    assert nb.posterior((1, 1, 1, 1)) == F(2, 5)


def test_hw5_sixteen_states_match_quoted_table():
    nb = BernoulliNB().fit(X, Y)
    for x in all_states(4):
        assert abs(float(nb.posterior(x)) - QUOTED_TABLE["".join(map(str, x))]) < 5e-5


def test_hw5_weights_are_a_joint_distribution():
    nb = BernoulliNB().fit(X, Y)
    assert sum(nb.weight(x, 1) for x in all_states(4)) == nb.prior[1]
    assert sum(nb.weight(x, c) for x in all_states(4) for c in (0, 1)) == 1


def test_hw5_log_odds_terms_add_up():
    nb = BernoulliNB().fit(X, Y)
    for x in all_states(4):
        p = float(nb.posterior(x))
        assert abs(sum(nb.log_odds_terms(x)) - math.log(p / (1 - p))) < 1e-12
        assert nb.log_odds_terms(x)[3] == 0.0          # medicine: 2/5 in both classes


def test_hw5_saturated_table_is_sparse_and_nb_misses_two_training_emails():
    cells = empirical_cells(X, Y)
    assert len(cells) == 7 and sum(n for n, _ in cells.values()) == 10
    nb = BernoulliNB().fit(X, Y)
    wrong = [i + 1 for i, (x, y) in enumerate(zip(X, Y)) if nb.predict(x) != y]
    assert wrong == [1, 8]                              # the two e-mails with alternative + medicine


def test_hw5_conjunction_memory():
    c = {tuple(p["features"]): p for p in mem.conjunction_memory(X, Y, WORDS, 2)}
    ad = c[("alternative", "medicine")]
    assert (ad["n"], ad["k"], ad["mle"], ad["post_mean"]) == (2, 2, 1, F(3, 4))
    md = c[("miracle", "medicine")]
    assert (md["n"], md["k"], md["post_mean"]) == (1, 1, F(2, 3))


# ---------- Beta -----------------------------------------------------------
def test_beta_closed_forms():
    for x in (0.1, 0.37, 0.9):
        assert abs(mem.beta_cdf(x, 3, 1) - x ** 3) < 1e-12        # Beta(3,1): F(x) = x^3
        assert abs(mem.beta_cdf(x, 1, 1) - x) < 1e-12
        assert abs(mem.beta_cdf(x, 2, 2) - (3 * x ** 2 - 2 * x ** 3)) < 1e-12
    lo, hi = mem.beta_interval(2, 2)
    assert abs(lo - 0.025 ** (1 / 3)) < 1e-9 and abs(hi - 0.975 ** (1 / 3)) < 1e-9
    assert [mem.beta_posterior_mean(n, n) for n in (2, 10, 100)] == [F(3, 4), F(11, 12), F(101, 102)]


# ---------- estimators in the bias-variance experiment ----------------------
def test_vectorised_naive_bayes_agrees_with_class():
    cells = empirical_cells(X, Y)
    n_x = np.array([cells.get(tuple(s), (0, 0))[0] for s in mem.STATES], float)
    k_x = np.array([cells.get(tuple(s), (0, 0))[1] for s in mem.STATES], float)
    nb = BernoulliNB(alpha=1, exact=False).fit(X, Y)
    ref = [nb.posterior(tuple(s)) for s in mem.STATES]
    assert np.allclose(mem.est_naive_bayes(n_x, k_x), ref)


def test_asymptotic_risks_are_ordered():
    truth = mem.make_truth()
    assert abs(truth["joint"].sum() - 1) < 1e-12
    r = mem.asymptotic_risk(truth)
    assert r["full_table"] < 1e-9 < r["pairwise"] < r["naive_bayes"]


def test_pairwise_logistic_recovers_a_pairwise_truth():
    truth = mem.make_truth(theta_mad_spam=0.0)           # no three-way term -> well specified
    p = mem.est_pairwise_logistic(truth["px"] * 1e9, truth["joint"][1] * 1e9, ridge=0.0)
    assert np.allclose(p, truth["post"], atol=1e-6)


# ---------- problem 6 ------------------------------------------------------
def test_hw6_transition_matrix_matches_handwritten():
    assert len(SYMBOLS) == 37
    t = mk.context_table(list(SYMBOLS), 1)
    rows = [[F(t[(a,)][b], sum(t[(a,)].values())) for b in ALPHABET] for a in ALPHABET]
    assert rows == [[0, F(4, 7), F(3, 7)], [F(4, 11), F(4, 11), F(3, 11)], [F(1, 6), F(1, 6), F(2, 3)]]


def test_hw6_dagger_runs_break_the_first_order_assumption():
    seq = list(SYMBOLS)
    assert [n for s, n in mk.run_lengths(seq) if s == "†"] == [3] * 6
    t3 = mk.context_table(seq, 3)
    assert t3[("†", "†", "†")]["†"] == 0 and sum(t3[("†", "†", "†")].values()) == 6
    assert t3[("*", "†", "†")] == Counter({"†": 3}) and t3[("□", "†", "†")] == Counter({"†": 3})
    t2 = mk.context_table(seq, 2)
    assert t2[("*", "†")] == Counter({"†": 3}) and t2[("□", "†")] == Counter({"†": 3})


def test_markov_order_tests():
    seq = list(SYMBOLS)
    assert mk.g2_statistic(seq, 1, 2) > 0 and mk.g2_statistic(seq, 1, 3) > mk.g2_statistic(seq, 1, 2)
    # The targeted statistic (run lengths of the dagger have zero variance) rejects decisively,
    disp = mk.run_dispersion_test(seq, list(ALPHABET), "†", B=20000, seed=6)
    assert disp["variance"] == 0.0 and disp["p"] < 1e-3
    # ... while the generic likelihood-ratio test has little power on 37 symbols.
    r3 = mk.markov_order_test(seq, ALPHABET, 3, B=2000, seed=6)
    assert 0.01 < r3["p"] < 0.10
    # A genuine first-order chain is not rejected and reproduces the fitted matrix.
    sim = mk.sample_first_order(seq, ALPHABET, 4000, np.random.default_rng(0))
    assert mk.markov_order_test(sim[:200], ALPHABET, 2, B=400, seed=1)["p"] > 0.01
    t = mk.context_table(sim, 1)
    assert abs(t[("†",)]["†"] / sum(t[("†",)].values()) - 2 / 3) < 0.04
    batch = mk.simulate_first_order_batch(seq, list(ALPHABET), 20000, np.random.default_rng(1))
    d = ALPHABET.index("†")
    stay = ((batch[:, :-1] == d) & (batch[:, 1:] == d)).sum() / (batch[:, :-1] == d).sum()
    assert abs(stay - 2 / 3) < 0.01


# ---------- n-gram models --------------------------------------------------
def _contexts():
    seen = [("medicine",), ("miracle", "medicine"), (BOS,), (BOS, "miracle", "medicine")]
    unseen = [("score", "miracle"), ("needs", "needs", "needs"), ()]
    return seen + unseen


def test_language_models_are_normalised():
    V = VOCAB + [EOS]
    padded = [pad(s) for s in SENTS]
    models = [mk.AddAlpha(V, 2, 0.5), mk.SupportInterpolation(V, 3, 10.0, 0.5),
              mk.KneserNey(V, 3, 0.75), mk.KneserNey(V, 1, 0.5)]
    for m in models:
        m.fit(padded, first=1)
        for ctx in _contexts():
            assert abs(sum(m.prob(ctx, w) for w in V) - 1.0) < 1e-12, (type(m).__name__, ctx)
    sym = list(SYMBOLS)
    for m in (mk.KneserNey(ALPHABET, 3, 0.75), mk.SupportInterpolation(ALPHABET, 3, 2.0, 0.5)):
        m.fit([sym], first=0)
        for ctx in [(), ("†",), ("†", "†", "†"), ("*", "*", "*")]:
            assert abs(sum(m.prob(ctx, w) for w in ALPHABET) - 1.0) < 1e-12


def test_support_interpolation_limits():
    V = VOCAB + [EOS]
    padded = [pad(s) for s in SENTS]
    ctx = ("miracle", "medicine")
    nc = mk.collect(padded, 2, first=1)
    c = nc.counts[2][ctx]
    mle = c["alternative"] / sum(c.values())
    tiny = mk.SupportInterpolation(V, 2, 1e-9, 0.5).fit(padded, first=1)
    huge = mk.SupportInterpolation(V, 2, 1e12, 0.5).fit(padded, first=1)
    uni = mk.AddAlpha(V, 0, 0.5).fit(padded, first=1)
    assert abs(tiny.prob(ctx, "alternative") - mle) < 1e-6          # tau -> 0: exact memory
    assert abs(huge.prob(ctx, "alternative") - uni.prob((), "alternative")) < 1e-6   # tau -> inf: unigram
    trace = []
    mk.SupportInterpolation(V, 2, 10.0, 0.5).fit(padded, first=1).prob(ctx, "alternative", trace)
    assert [round(t["lambda"], 6) for t in trace[1:]] == [round(t["n"] / (t["n"] + 10.0), 6) for t in trace[1:]]


def test_absorbing_chain_reproduces_sentence_statistics():
    ch = mk.absorbing_chain(SENTS)
    assert abs(ch["absorption_prob_from_bos"] - 1.0) < 1e-12
    assert abs(ch["expected_length"] - np.mean([len(s) for s in SENTS])) < 1e-10
    rate = Counter(w for s in SENTS for w in s)
    for s, v in zip(ch["states"][1:], ch["expected_visits_from_bos"][1:]):
        assert abs(v - rate[s] / len(SENTS)) < 1e-10
    assert np.allclose(ch["Q"].sum(1) + ch["R"], 1.0)


def test_decay_without_forgetting_equals_batch_estimate():
    target = (BOS, "miracle")
    p = mk.decayed_tracking(SENTS, 1.0, target, alpha=0.1)
    k = sum(s[0] == "miracle" for s in SENTS)
    assert abs(p[-1] - (k + 0.1) / (len(SENTS) + 0.1 * (len(VOCAB) + 1))) < 1e-12


# ---------- embeddings -----------------------------------------------------
def test_embeddings():
    v2i = {w: i for i, w in enumerate(VOCAB)}
    C = em.cooccurrence(SENTS, v2i)
    P = em.ppmi(C)
    assert np.allclose(C, C.T) and np.allclose(P, P.T) and (P >= 0).all()
    E, S = em.svd_embeddings(P, 8)
    assert E.shape == (len(VOCAB), 8) and np.isfinite(E).all() and (np.diff(S) <= 1e-12).all()
    table = em.build_ngram_table(VOCAB, E)
    e, cover = em.oov_embedding("xyzzy", table, 8)
    assert cover == 0.0 and not e.any()
    e, cover = em.oov_embedding("medicinal", table, 8)
    assert cover > 0.5 and VOCAB[int(np.argmax(em.cosine_to_vocab(e, E)))] == "medicine"


# ---------- HMM ------------------------------------------------------------
def _random_hmm(rng, K=3, T=5):
    pi = rng.dirichlet(np.ones(K))
    A = rng.dirichlet(np.ones(K), size=K)
    L = rng.uniform(0.05, 1.0, size=(T, K))
    return pi, A, L


def test_forward_backward_equals_brute_force():
    rng = np.random.default_rng(0)
    for _ in range(20):
        pi, A, L = _random_hmm(rng)
        g, xi, ll = H.forward_backward(pi, A, L)
        g_ref, ll_ref = H.brute_force_gamma(pi, A, L)
        assert np.allclose(g, g_ref, atol=1e-12) and abs(ll - ll_ref) < 1e-12
        assert np.allclose(g.sum(1), 1) and abs(xi.sum() - (L.shape[0] - 1)) < 1e-12
        assert np.allclose(xi.sum(1), g[:-1].sum(0))


def test_viterbi_equals_brute_force():
    from itertools import product
    rng = np.random.default_rng(1)
    for _ in range(20):
        pi, A, L = _random_hmm(rng, K=3, T=5)
        best, arg = -1.0, None
        for z in product(range(3), repeat=5):
            p = pi[z[0]] * L[0, z[0]] * np.prod([A[z[t - 1], z[t]] * L[t, z[t]] for t in range(1, 5)])
            if p > best:
                best, arg = p, list(z)
        assert H.viterbi(pi, A, L) == arg


def test_baum_welch_never_decreases_its_objective():
    v2i = {w: i for i, w in enumerate(VOCAB)}
    pi, A, B = H.seed_parameters(VOCAB, pipeline.SEED_WORDS, pipeline.SEED_A)
    ids = [[v2i[w] for w in s] for s in SENTS]
    pi, A, B, trace = H.baum_welch(ids, pi, A, B, iters=40)
    assert (np.diff(trace) > -1e-8).all() and trace[-1] > trace[0]
    assert np.allclose(A.sum(1), 1) and np.allclose(B.sum(1), 1) and abs(pi.sum() - 1) < 1e-12


def _trained():
    pi, A, B, _ = pipeline.train_hmm(SENTS, VOCAB)
    v2i = {w: i for i, w in enumerate(VOCAB)}
    E, _ = em.svd_embeddings(em.ppmi(em.cooccurrence(SENTS, v2i)), 8)
    return pi, A, B, H.OOVEmission(VOCAB, B, E, em.build_ngram_table(VOCAB, E))


def test_hmm_state_names_describe_what_was_learned():
    _, _, B, _ = _trained()
    top = [VOCAB[int(np.argmax(B[k]))] for k in range(4)]
    assert top == ["miracle", "money", "foot", "basketball"]      # order of pipeline.STATE_NAMES


def test_oov_token_keeps_its_position_and_gets_a_posterior():
    pi, A, B, emit = _trained()
    toks = "miracle xyzzy cure".split()
    L, info = emit.matrix(toks, "flat")
    assert L.shape == (3, 4) and info[1]["oov"] and (L[1] == 1).all()
    g, _, _ = H.forward_backward(pi, A, L)
    assert np.allclose(g.sum(1), 1)
    # A flat likelihood is exactly "marginalise the unknown word": two-step transition A @ A.
    pred = (pi * L[0]) @ A @ A * L[2]
    assert np.allclose(g[2], pred / pred.sum())
    # Deleting the token is a different (one-step) computation and gives a different answer.
    drop = (pi * L[0]) @ A * L[2]
    assert abs(g[2] - drop / drop.sum()).max() > 0.05


def test_subword_mode_moves_an_oov_word_toward_its_neighbour():
    pi, A, B, emit = _trained()
    toks = "doctor recommends medicinal cure".split()
    flat = H.forward_backward(pi, A, emit.matrix(toks, "flat")[0])[0][2]
    sub = H.forward_backward(pi, A, emit.matrix(toks, "subword")[0])[0][2]
    medical = pipeline.STATE_KEYS.index("medical")
    assert sub[medical] > flat[medical]
    lik, info = emit.likelihood("xyzzy", "subword")       # nothing known about it -> flat
    assert (lik == 1).all() and info["coverage"] == 0.0


# Short descriptions shown in the report next to each check.
DESCRIPTIONS = {
    "test_hw5_parameters_match_handwritten_values": "第 5 题：8 个条件概率与手写值相等（4/5, 2/5, 2/5, 1/5 与 1/5, 3/5, 2/5, 4/5）",
    "test_hw5_answers_b_and_c": "第 5 题：(b) 3/35、(c) 2/5 为精确分数",
    "test_hw5_sixteen_states_match_quoted_table": "第 5 题：16 种输入的后验与前文表格逐项一致",
    "test_hw5_weights_are_a_joint_distribution": "第 5 题：16 个权重之和等于先验，两类合计为 1",
    "test_hw5_log_odds_terms_add_up": "第 5 题：各词的对数证据之和等于 logit 后验；medicine 一项恒为 0",
    "test_hw5_saturated_table_is_sparse_and_nb_misses_two_training_emails": "第 5 题：训练集覆盖 7/16 格；朴素贝叶斯判错第 1、8 封",
    "test_hw5_conjunction_memory": "组合记忆：alternative+medicine 为 2/2，后验均值 3/4",
    "test_beta_closed_forms": "Beta 分布：CDF 与分位数对照闭式解",
    "test_vectorised_naive_bayes_agrees_with_class": "模拟用的向量化朴素贝叶斯与逐项实现一致",
    "test_asymptotic_risks_are_ordered": "模拟：无限数据下 全表 0 < 成对 < 朴素贝叶斯",
    "test_pairwise_logistic_recovers_a_pairwise_truth": "模拟：真分布只有成对交互时，成对模型能精确恢复",
    "test_hw6_transition_matrix_matches_handwritten": "第 6 题：转移矩阵与手写分数逐项相等",
    "test_hw6_dagger_runs_break_the_first_order_assumption": "第 6 题：† 的 6 段游程长度全为 3；3 阶上下文决定下一个符号",
    "test_markov_order_tests": "第 6 题：游程离散度检验拒绝一阶链（p < 0.001）；通用 G² 检验功效低；真正的一阶链不被拒绝",
    "test_language_models_are_normalised": "add-α、支持度插值、Kneser–Ney 在见过和没见过的上下文上都归一",
    "test_support_interpolation_limits": "支持度插值：τ→0 退化为精确记忆，τ→∞ 退化为 unigram",
    "test_absorbing_chain_reproduces_sentence_statistics": "吸收链：期望访问次数等于每句平均词频，期望句长等于平均句长",
    "test_decay_without_forgetting_equals_batch_estimate": "衰减计数：ρ=1 时等于一次性统计",
    "test_embeddings": "PPMI 对称非负；SVD 向量有限；medicinal 的最近邻是 medicine",
    "test_forward_backward_equals_brute_force": "forward–backward 与枚举全部 K^T 条路径的结果相等（20 个随机 HMM）",
    "test_viterbi_equals_brute_force": "Viterbi 与枚举得到的最优路径相同",
    "test_baum_welch_never_decreases_its_objective": "Baum–Welch 的目标函数单调不减",
    "test_hmm_state_names_describe_what_was_learned": "HMM 四个状态的名字与学到的高频词相符",
    "test_oov_token_keeps_its_position_and_gets_a_posterior": "OOV 保留位置：后验等于对未知词求和（多走一步转移），与删除它的结果不同",
    "test_subword_mode_moves_an_oov_word_toward_its_neighbour": "子词相似把 medicinal 拉向“伤病医疗”；xyzzy 没有可用子词时保持中性",
}
