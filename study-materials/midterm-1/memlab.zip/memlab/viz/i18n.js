(function () {
  'use strict';

  const ROWS = [
    // Page chrome and static narrative.
    [`记忆惯性实验`, `Memory Inertia Lab`, `Labor zur Gedächtnisträgheit`],
    [`概率作业 · 第 5、6 题延伸`, `Probability homework · extensions to Problems 5 and 6`, `Wahrscheinlichkeitsaufgaben · Erweiterungen zu Aufgaben 5 und 6`],
    [`一个组合要见过几次，才值得被记住？这里用三份数据回答：第 5 题的 10 封邮件、第 6 题的 37 个符号、ZIP 里的 160 条合成语料。`, `How often must a combination be observed before it is worth remembering? We answer with three datasets: the 10 emails from Problem 5, the 37 symbols from Problem 6, and the 160 synthetic documents in the ZIP archive.`, `Wie oft muss eine Kombination beobachtet werden, bevor man sie sich merken sollte? Wir antworten mit drei Datensätzen: den 10 E-Mails aus Aufgabe 5, den 37 Symbolen aus Aufgabe 6 und den 160 synthetischen Dokumenten im ZIP-Archiv.`],
    [`每一节的数据和参数都可以直接改：训练表、符号序列、平滑强度、模拟的真分布。图表在浏览器里实时重算。文字结论针对题目原始数据和默认参数，由`, `Every section is editable: the training table, symbol sequence, smoothing strength, and the simulation's true distribution. Charts are recomputed live in the browser. Written conclusions use the original problem data and default parameters and were computed by`, `In jedem Abschnitt lassen sich Daten und Parameter direkt ändern: Trainingstabelle, Symbolfolge, Glättungsstärke und die wahre Verteilung der Simulation. Die Diagramme werden im Browser live neu berechnet. Die Textaussagen beziehen sich auf die ursprünglichen Aufgabendaten und Standardparameter und wurden berechnet von`],
    [`算出。`, `.`, `.`],
    [`目录`, `Contents`, `Inhalt`],
    [`第 5 题：朴素贝叶斯`, `Problem 5: Naive Bayes`, `Aufgabe 5: Naive Bayes`],
    [`组合记忆`, `Conjunction memory`, `Kombinationsgedächtnis`],
    [`偏差–方差模拟`, `Bias–variance simulation`, `Bias-Varianz-Simulation`],
    [`第 6 题：符号链`, `Problem 6: symbol chain`, `Aufgabe 6: Symbolkette`],
    [`n-gram 记忆`, `n-gram memory`, `n-Gramm-Gedächtnis`],
    [`词向量与 HMM`, `Word vectors and HMM`, `Wortvektoren und HMM`],
    [`代码与检查`, `Code and checks`, `Code und Prüfungen`],

    [`第 5 题`, `Problem 5`, `Aufgabe 5`],
    [`10 封邮件，16 种输入`, `10 emails, 16 possible inputs`, `10 E-Mails, 16 mögliche Eingaben`],
    [`点一个词切换它是否出现。条形图是每个词加在对数几率上的证据，各项相加就是朴素贝叶斯的结论。16 格是全部输入的后验，圆点是落在该格的训练邮件。下面的训练表也可以改，所有结果跟着变。`, `Click a word to toggle whether it is present. Each bar is that word's contribution to the log odds; adding the contributions gives the Naive Bayes result. The 16 cells show the posterior for every input, and dots mark training emails in each cell. You can also edit the training table below, and every result will update.`, `Klicken Sie auf ein Wort, um sein Vorkommen umzuschalten. Jeder Balken zeigt den Beitrag dieses Wortes zu den Log-Odds; ihre Summe ergibt das Naive-Bayes-Ergebnis. Die 16 Felder zeigen die Posteriorwahrscheinlichkeit für jede Eingabe, Punkte markieren die Trainings-E-Mails. Auch die Trainingstabelle unten ist editierbar; alle Ergebnisse werden entsprechend aktualisiert.`],
    [`每个词贡献的证据（似然比）`, `Evidence contributed by each word (likelihood ratio)`, `Evidenzbeitrag jedes Wortes (Likelihood-Verhältnis)`],
    [`向右偏向垃圾邮件，向左偏向非垃圾。横轴是对数刻度，所以几个词的条形可以首尾相加。下表是估计出的参数，后两列是这个词出现和不出现时的似然比。`, `Right favors spam and left favors non-spam. The horizontal axis is logarithmic, so the word-level bars add. The table gives the estimated parameters; its last two columns are the likelihood ratios when a word is present or absent.`, `Nach rechts spricht die Evidenz für Spam, nach links für Nicht-Spam. Die horizontale Achse ist logarithmisch, daher addieren sich die Wortbeiträge. Die Tabelle zeigt die geschätzten Parameter; die letzten beiden Spalten enthalten die Likelihood-Verhältnisse bei vorhandenem bzw. fehlendem Wort.`],
    [`16 种输入的 P(垃圾 | x)`, `P(spam | x) for all 16 inputs`, `P(Spam | x) für alle 16 Eingaben`],
    [`非垃圾`, `not spam`, `kein Spam`],
    [`垃圾`, `spam`, `Spam`],
    [`训练邮件：垃圾`, `training email: spam`, `Trainings-E-Mail: Spam`],
    [`训练邮件：非垃圾`, `training email: not spam`, `Trainings-E-Mail: kein Spam`],
    [`M = miracle，A = alternative，D = medicine，B = basketball。没有圆点的格子在训练集里没出现过，直接数频率得到 0/0。点任意一格可以选中它。`, `M = miracle, A = alternative, D = medicine, B = basketball. Cells without dots were never observed in the training set, so a direct frequency estimate is 0/0. Click any cell to select it.`, `M = miracle, A = alternative, D = medicine, B = basketball. Felder ohne Punkte wurden im Trainingssatz nie beobachtet; eine direkte Häufigkeitsschätzung ergibt daher 0/0. Klicken Sie auf ein Feld, um es auszuwählen.`],
    [`训练表（点单元格可以改）`, `Training table (click a cell to edit)`, `Trainingstabelle (zum Bearbeiten auf eine Zelle klicken)`],
    [`16 种输入逐项展开`, `All 16 inputs in detail`, `Alle 16 Eingaben im Detail`],
    [`“直接数频率”一列是不做任何假设时对 P(垃圾 | x) 的估计，没有数据的格子无法估计。点一行可以选中该输入。`, `The “direct frequency” column estimates P(spam | x) without modeling assumptions. Cells with no data cannot be estimated. Click a row to select that input.`, `Die Spalte „direkte Häufigkeit“ schätzt P(Spam | x) ohne Modellannahmen. Felder ohne Daten sind nicht schätzbar. Klicken Sie auf eine Zeile, um die Eingabe auszuwählen.`],

    [`5(c) 延伸`, `Extension of 5(c)`, `Erweiterung zu 5(c)`],
    [`2/2 还不是 100%`, `2/2 is not yet 100%`, `2/2 sind noch keine 100 %`],
    [`把“某几个词同时出现”当成条件，数一数满足条件的邮件里垃圾占多少。支持数 n 很小时，频率 k/n 只能取 0、1/2、1 这样的粗值。给概率 p 一个 Beta(1,1) 先验，后验是 Beta(1+k, 1+n−k)，均值 (k+1)/(n+2)，区间的宽度就是证据的多少。`, `Condition on several words appearing together, then count the spam messages among the matching emails. When support n is small, the frequency k/n can take only coarse values such as 0, 1/2, and 1. With a Beta(1,1) prior for p, the posterior is Beta(1+k, 1+n−k), its mean is (k+1)/(n+2), and the interval width shows how much evidence is available.`, `Wir bedingen darauf, dass mehrere Wörter gemeinsam vorkommen, und zählen dann die Spam-Nachrichten unter den passenden E-Mails. Bei kleinem Stichprobenumfang n kann k/n nur grobe Werte wie 0, 1/2 und 1 annehmen. Mit einem Beta(1,1)-Prior für p lautet der Posterior Beta(1+k, 1+n−k), sein Mittelwert ist (k+1)/(n+2), und die Intervallbreite zeigt die verfügbare Evidenzmenge.`],
    [`同时出现时是垃圾邮件的概率`, `Probability of spam when the words co-occur`, `Spam-Wahrscheinlichkeit bei gemeinsamem Auftreten`],
    [`圆点是后验均值，横线是 95% 可信区间，短竖线是频率 k/n。上半按上一节当前的训练表计算，改表会跟着变；下半是 160 条合成语料里的四个组合。`, `Dots are posterior means, horizontal lines are 95% credible intervals, and short vertical marks are frequencies k/n. The upper half uses the current training table from the preceding section and updates with it; the lower half shows four conjunctions from the 160 synthetic documents.`, `Punkte sind Posterior-Mittelwerte, horizontale Linien 95-%-Glaubwürdigkeitsintervalle und kurze vertikale Marken die Häufigkeiten k/n. Die obere Hälfte verwendet die aktuelle Trainingstabelle des vorigen Abschnitts und wird mit ihr aktualisiert; die untere Hälfte zeigt vier Kombinationen aus den 160 synthetischen Dokumenten.`],
    [`k/n 对应的后验分布`, `Posterior distribution for k/n`, `Posteriorverteilung zu k/n`],
    [`n 支持数`, `n support`, `n Beobachtungen`],
    [`k 垃圾数`, `k spam`, `k Spam`],
    [`真实概率是 0.7 时，连续两封都是垃圾的概率是 0.7² = 0.49；是 0.5 时也有 0.25。所以 2/2 说明偏向垃圾，但分不清 0.7 和 1。`, `If the true probability is 0.7, two consecutive spam messages occur with probability 0.7² = 0.49; even at 0.5 the probability is 0.25. Thus 2/2 favors spam but cannot distinguish 0.7 from 1.`, `Bei einer wahren Wahrscheinlichkeit von 0,7 treten zwei aufeinanderfolgende Spam-Nachrichten mit Wahrscheinlichkeit 0,7² = 0,49 auf; selbst bei 0,5 beträgt sie 0,25. Daher spricht 2/2 für Spam, unterscheidet aber 0,7 nicht von 1.`],

    [`模拟实验`, `Simulation experiment`, `Simulationsexperiment`],
    [`记得越细，越吃数据`, `Finer memory needs more data`, `Feineres Gedächtnis benötigt mehr Daten`],
    [`第 5 题只有 10 封邮件，比不出三种估计谁好。这里换成一个答案已知的生成分布。`, `Problem 5 has only 10 emails, too few to compare the three estimators. Here we use a generative distribution whose answer is known.`, `Aufgabe 5 enthält nur 10 E-Mails — zu wenige, um die drei Schätzer zu vergleichen. Hier verwenden wir eine generative Verteilung, deren Lösung bekannt ist.`],
    [`这个分布是我为实验设定的，不是题目数据`, `This distribution was specified for the experiment; it is not the problem data`, `Diese Verteilung wurde für das Experiment festgelegt; sie stammt nicht aus den Aufgabendaten`],
    [`：四个词沿用题目的参数，垃圾类里 alternative 与 medicine 相吸，非垃圾类里 medicine 与 basketball 相吸，垃圾类里再加一项三元交互。`, `: the four words retain the problem's parameters; alternative and medicine attract in the spam class, medicine and basketball attract in the non-spam class, and the spam class also has a three-way interaction.`, `: Die vier Wörter behalten die Parameter der Aufgabe; alternative und medicine ziehen sich in der Spam-Klasse an, medicine und basketball in der Nicht-Spam-Klasse, und die Spam-Klasse enthält zusätzlich eine Dreifachinteraktion.`],
    [`三个交互强度可以拖动。把它们都拉到 0，条件独立就成立，朴素贝叶斯不再有偏差。纵轴是估计出的后验与真后验之间的期望 KL 散度，越低越好。`, `You can drag the three interaction strengths. Set all of them to 0 and conditional independence holds, eliminating Naive Bayes bias. The vertical axis is the expected KL divergence between the estimated and true posterior; lower is better.`, `Die drei Interaktionsstärken lassen sich verschieben. Werden alle auf 0 gesetzt, gilt bedingte Unabhängigkeit und der Naive-Bayes-Bias verschwindet. Die vertikale Achse zeigt die erwartete KL-Divergenz zwischen geschätztem und wahrem Posterior; kleiner ist besser.`],
    [`三种估计的超额对数损失随样本量的变化`, `Excess log loss of three estimators versus sample size`, `Zusätzlicher Log-Loss dreier Schätzer nach Stichprobengröße`],
    [`朴素贝叶斯：8 个参数，不记组合`, `Naive Bayes: 8 parameters, no conjunction memory`, `Naive Bayes: 8 Parameter, kein Kombinationsgedächtnis`],
    [`成对交互 logistic：11 个参数`, `Pairwise-interaction logistic model: 11 parameters`, `Logistisches Modell mit Paarinteraktionen: 11 Parameter`],
    [`16 格全表：每格一个参数`, `Full 16-cell table: one parameter per cell`, `Vollständige 16-Felder-Tabelle: ein Parameter je Feld`],
    [`两条轴都是对数刻度。底部色带标出每个样本量下损失最低的方法。`, `Both axes use logarithmic scales. The color band at the bottom marks the lowest-loss method at each sample size.`, `Beide Achsen sind logarithmisch skaliert. Das Farbband unten markiert für jede Stichprobengröße die Methode mit dem kleinsten Verlust.`],
    [`数据无限多时各方法收敛到哪里`, `Where each method converges with unlimited data`, `Grenzwerte der Methoden bei unbegrenzt vielen Daten`],
    [`每列是一种输入（miracle, alternative, medicine, basketball）。第一行是真后验 P(垃圾 | x)，下面两行与它不同的地方就是该方法去不掉的偏差。全表的极限等于真后验。`, `Each column is one input (miracle, alternative, medicine, basketball). The first row is the true posterior P(spam | x); differences in the next two rows are irreducible bias. The full table converges to the true posterior.`, `Jede Spalte entspricht einer Eingabe (miracle, alternative, medicine, basketball). Die erste Zeile ist der wahre Posterior P(Spam | x); Abweichungen in den nächsten beiden Zeilen sind nicht beseitigbarer Bias. Die vollständige Tabelle konvergiert zum wahren Posterior.`],
    [`数据表`, `Data table`, `Datentabelle`],

    [`第 6 题`, `Problem 6`, `Aufgabe 6`],
    [`† 总是三个一组`, `† always comes in groups of three`, `† tritt immer in Dreiergruppen auf`],
    [`印刷的符号行被圈画盖住了几处。下面这个读法算出的一阶转移概率和手写矩阵逐项相等，所以按它来分析。点任意一个符号可以改它；也可以让一阶链自己生成一条，看看真正“无记忆”的序列长什么样。`, `Several symbols in the printed row are obscured by annotations. The reading below reproduces every entry of the handwritten first-order transition matrix, so it is the one analyzed here. Click any symbol to change it, or let a first-order chain generate a sequence to see what genuinely “memoryless” data look like.`, `Mehrere Symbole in der gedruckten Zeile sind durch Markierungen verdeckt. Die unten verwendete Lesart reproduziert jeden Eintrag der handschriftlichen Übergangsmatrix erster Ordnung und wird daher analysiert. Klicken Sie auf ein Symbol, um es zu ändern, oder lassen Sie eine Kette erster Ordnung eine Folge erzeugen, um wirklich „gedächtnislose“ Daten zu sehen.`],
    [`铭文序列`, `Inscription sequence`, `Inschriftfolge`],
    [`一阶转移矩阵（最大似然）`, `First-order transition matrix (maximum likelihood)`, `Übergangsmatrix erster Ordnung (Maximum Likelihood)`],
    [`行是当前符号，列是下一个符号，括号里是计数。`, `Rows are current symbols, columns are next symbols, and parentheses contain counts.`, `Zeilen sind aktuelle Symbole, Spalten die Folgesymbole; in Klammern stehen die Anzahlen.`],
    [`一阶假设要求上面各行的比例都相同。`, `The first-order assumption requires the proportions above to be the same in every row.`, `Die Annahme erster Ordnung verlangt, dass die obigen Anteile in jeder Zeile gleich sind.`],
    [`一阶链预期的段数`, `expected runs under a first-order chain`, `erwartete Läufe unter einer Kette erster Ordnung`],
    [`实际段数`, `observed runs`, `beobachtete Läufe`],
    [`一阶假设的检验（自助法）`, `Tests of the first-order assumption (bootstrap)`, `Tests der Annahme erster Ordnung (Bootstrap)`],
    [`逐个符号预测的平均码长`, `Mean code length for sequential symbol prediction`, `Mittlere Codelänge bei sequenzieller Symbolvorhersage`],
    [`预测第 t 个符号时只用前 t−1 个符号的计数。单位 bit/符号，越低越好。竖线是不做任何学习的均匀编码。`, `When predicting symbol t, only counts from the preceding t−1 symbols are used. Units are bits per symbol; lower is better. The vertical line is uniform coding with no learning.`, `Bei der Vorhersage von Symbol t werden nur Zählungen der vorangehenden t−1 Symbole verwendet. Einheit: Bit pro Symbol; kleiner ist besser. Die vertikale Linie entspricht einer Gleichverteilung ohne Lernen.`],

    [`160 条语料`, `160 documents`, `160 Dokumente`],
    [`有支持就记住，稀疏就回退`, `Remember with support; back off when sparse`, `Bei Evidenz merken, bei Sparsity zurückfallen`],
    [`输入上文，看每一层记忆有多少支持`, `Enter a context to inspect support at every memory level`, `Kontext eingeben und Evidenz auf jeder Gedächtnisebene prüfen`],
    [`^ 表示句首，只取最后三个词作上文。三个面板是同一组候选词在三种模型下的概率。`, `^ marks the start of a sentence; only the last three words are used as context. The three panels show probabilities for the same candidate words under three models.`, `^ markiert den Satzanfang; als Kontext werden nur die letzten drei Wörter verwendet. Die drei Felder zeigen die Wahrscheinlichkeiten derselben Kandidatenwörter unter drei Modellen.`],
    [`没见过的句子上的困惑度`, `Perplexity on unseen sentences`, `Perplexität auf ungesehenen Sätzen`],
    [`分组 5 折交叉验证，包含句末符。越低越好。拖动上面的 α、τ、D 会重算。`, `Grouped 5-fold cross-validation, including the end-of-sentence token. Lower is better. Drag α, τ, or D above to recompute.`, `Gruppierte 5-fache Kreuzvalidierung einschließlich Satzende-Token. Kleiner ist besser. Durch Verschieben von α, τ oder D wird neu berechnet.`],
    [`不做平滑时，测试词的去向`, `What happens to test words without smoothing`, `Was mit Testwörtern ohne Glättung geschieht`],
    [`上下文没见过（0/0）`, `unseen context (0/0)`, `ungesehener Kontext (0/0)`],
    [`被判为概率 0`, `assigned probability 0`, `Wahrscheinlichkeit 0 zugewiesen`],
    [`有正概率`, `positive probability`, `positive Wahrscheinlichkeit`],
    [`只要有一个词概率为 0，整句的概率就是 0，困惑度无穷大。`, `If even one word has probability 0, the sentence probability is 0 and perplexity is infinite.`, `Hat auch nur ein Wort Wahrscheinlichkeit 0, ist die Satzwahrscheinlichkeit 0 und die Perplexität unendlich.`],
    [`带遗忘的计数：句首是 miracle 的概率`, `Decayed counts: probability that a sentence starts with miracle`, `Vergessende Zählungen: Wahrscheinlichkeit für miracle am Satzanfang`],
    [`ρ = 1，不遗忘`, `ρ = 1, no forgetting`, `ρ = 1, kein Vergessen`],
    [`该段的真实频率`, `true frequency in the segment`, `wahre Häufigkeit im Abschnitt`],
    [`吸收链：每个词在一句里期望出现几次`, `Absorbing chain: expected count of each word per sentence`, `Absorbierende Kette: erwartete Anzahl jedes Wortes pro Satz`],

    [`词向量 · OOV`, `Word vectors · OOV`, `Wortvektoren · OOV`],
    [`不认识的词也占一个位置`, `An unknown word still occupies a position`, `Auch ein unbekanntes Wort belegt eine Position`],
    [`词向量从语料自身得到：窗口 2 的共现计数，取 PPMI，再做 SVD 保留 8 维。图上是前两维。位置相近说明上下文相似，颜色说明这个词偏向哪一类，这是两个不同的问题。点一个词看它的近邻；在输入框里写一个词表外的词，看它的字符片段把它放到哪里。`, `Word vectors are learned from the corpus itself: window-2 co-occurrence counts, PPMI, then SVD retaining 8 dimensions. The plot shows the first two. Nearby positions indicate similar contexts, while color indicates class association—two different questions. Click a word to see its neighbors, or type an out-of-vocabulary word to see where its character fragments place it.`, `Die Wortvektoren werden aus dem Korpus selbst gelernt: Kookkurrenzzählungen mit Fenster 2, PPMI und anschließend SVD mit 8 Dimensionen. Gezeigt werden die ersten beiden. Räumliche Nähe bedeutet ähnliche Kontexte, die Farbe dagegen Klassenzugehörigkeit — zwei verschiedene Fragen. Klicken Sie auf ein Wort, um seine Nachbarn zu sehen, oder geben Sie ein Wort außerhalb des Vokabulars ein, um zu sehen, wo seine Zeichenfragmente es einordnen.`],
    [`26 个词的前两个 SVD 维度`, `First two SVD dimensions of 26 words`, `Erste zwei SVD-Dimensionen von 26 Wörtern`],
    [`多见于非垃圾`, `more common in non-spam`, `häufiger in Nicht-Spam`],
    [`两类差不多`, `similar in both classes`, `in beiden Klassen ähnlich`],
    [`多见于垃圾`, `more common in spam`, `häufiger in Spam`],
    [`你输入的词`, `word you entered`, `eingegebenes Wort`],
    [`词表：出现概率与向量`, `Vocabulary: occurrence probabilities and vectors`, `Vokabular: Auftretenswahrscheinlichkeiten und Vektoren`],
    [`下面输入一句英文。词表外的词有三种处理：`, `Enter an English sentence below. Out-of-vocabulary words can be handled in three ways:`, `Geben Sie unten einen englischen Satz ein. Wörter außerhalb des Vokabulars können auf drei Arten behandelt werden:`],
    [`保留位置`, `keep position`, `Position behalten`],
    [`时它的似然对四个状态相同，后验完全由前后文决定；`, ` gives it the same likelihood in all four states, so its posterior is determined entirely by context;`, ` gibt ihm in allen vier Zuständen dieselbe Likelihood, sodass sein Posterior vollständig vom Kontext bestimmt wird;`],
    [`子词相似`, `subword similarity`, `Subwortähnlichkeit`],
    [`用字符 3 到 5 元组找最像的词表词，按覆盖率加权；`, ` finds the most similar vocabulary words using character 3- to 5-grams and weights by coverage;`, ` sucht mit Zeichen-3- bis 5-Grammen die ähnlichsten Vokabularwörter und gewichtet nach Abdeckung;`],
    [`删除`, `delete`, `löschen`],
    [`是把它从序列里拿掉，后面的词因此少走一步转移。`, ` removes it from the sequence, so the following word undergoes one fewer transition.`, ` entfernt es aus der Folge, sodass das nächste Wort einen Übergang weniger durchläuft.`],
    [`每个位置的隐状态后验`, `Hidden-state posterior at each position`, `Posterior der verborgenen Zustände an jeder Position`],
    [`词表外的词`, `Out-of-vocabulary words`, `Wörter außerhalb des Vokabulars`],
    [`保留位置 + 子词相似`, `keep position + subword similarity`, `Position behalten + Subwortähnlichkeit`],
    [`使用的信息`, `Information used`, `Verwendete Information`],
    [`整句（前向 + 后向）`, `full sentence (forward + backward)`, `ganzer Satz (vorwärts + rückwärts)`],
    [`只看前文（前向）`, `past only (forward)`, `nur vorheriger Kontext (vorwärts)`],
    [`训练得到的状态与转移`, `Learned states and transitions`, `Gelernte Zustände und Übergänge`],
    [`发射概率 P(词 | 状态)，全部 26 个词`, `Emission probabilities P(word | state), all 26 words`, `Emissionswahrscheinlichkeiten P(Wort | Zustand), alle 26 Wörter`],

    [`实现 · 核对`, `Implementation · verification`, `Implementierung · Prüfung`],
    [`核心代码与检查项`, `Core code and checks`, `Kerncode und Prüfungen`],
    [`完整工程在 ZIP 里：`, `The complete project is in the ZIP archive:`, `Das vollständige Projekt befindet sich im ZIP-Archiv:`],
    [`六个模块，`, `six modules,`, `sechs Module,`],
    [`重算全部数字并生成这个页面，`, `recomputes every number and generates this page, and`, `berechnet alle Zahlen neu und erzeugt diese Seite;`],
    [`跑下面的检查。页面里实时重算用的是同一套算法的 JavaScript 版本，默认参数下的结果与 Python 逐项对照过。`, `runs the checks below. Live browser calculations use JavaScript versions of the same algorithms, and their default-parameter results were checked entry by entry against Python.`, `führt die folgenden Prüfungen aus. Die Live-Berechnungen im Browser verwenden JavaScript-Versionen derselben Algorithmen; ihre Ergebnisse mit Standardparametern wurden elementweise mit Python abgeglichen.`],
    [`合成语料是模板拼出来的，朴素贝叶斯在上面的 5 折准确率是 100%，所以分类方法的比较放在模拟实验里。`, `The synthetic corpus is assembled from templates, and Naive Bayes attains 100% 5-fold accuracy on it; classification methods are therefore compared in the simulation experiment.`, `Das synthetische Korpus wurde aus Vorlagen zusammengesetzt; Naive Bayes erreicht darauf in der 5-fachen Kreuzvalidierung 100 % Genauigkeit. Daher werden die Klassifikationsmethoden im Simulationsexperiment verglichen.`],
    [`子词向量是把 26 个词的向量按字符片段取平均得到的，没有和词向量一起训练。覆盖率低时它几乎不起作用，这是有意的。`, `Subword vectors average the 26 word vectors over character fragments; they are not trained jointly with the word vectors. At low coverage they have almost no effect, by design.`, `Subwortvektoren mitteln die 26 Wortvektoren über Zeichenfragmente; sie werden nicht gemeinsam mit den Wortvektoren trainiert. Bei geringer Abdeckung wirken sie absichtlich kaum.`],
    [`平滑参数的默认值 α = 0.5、τ = 10 取自前文，Kneser–Ney 折扣 0.75 是常用值。默认值是事先固定的，没有在评测数据上调。`, `The default smoothing values α = 0.5 and τ = 10 come from the preceding discussion; the Kneser–Ney discount 0.75 is conventional. Defaults were fixed in advance, not tuned on evaluation data.`, `Die Standardwerte der Glättung, α = 0,5 und τ = 10, stammen aus der vorangehenden Diskussion; der Kneser–Ney-Discount 0,75 ist üblich. Die Standardwerte wurden vorab festgelegt und nicht an den Evaluationsdaten angepasst.`],

    // Reusable controls, table labels, model names, and status text.
    [`邮件里出现的词`, `Words present in the email`, `In der E-Mail vorkommende Wörter`],
    [`(b) 打篮球伤了脚，要药`, `(b) hurt a foot playing basketball; needs medicine`, `(b) Fuß beim Basketball verletzt; braucht Medizin`],
    [`参数估计`, `Parameter estimate`, `Parameterschätzung`],
    [`最大似然（题目）`, `Maximum likelihood (problem)`, `Maximum Likelihood (Aufgabe)`],
    [`Beta(1,1) 平滑`, `Beta(1,1) smoothing`, `Beta(1,1)-Glättung`],
    [`把当前输入加为垃圾邮件`, `Add current input as spam`, `Aktuelle Eingabe als Spam hinzufügen`],
    [`把当前输入加为非垃圾邮件`, `Add current input as non-spam`, `Aktuelle Eingabe als Nicht-Spam hinzufügen`],
    [`恢复题目的 10 封`, `Restore the problem's 10 emails`, `Die 10 E-Mails der Aufgabe wiederherstellen`],
    [`P(垃圾 | x) =`, `P(spam | x) =`, `P(Spam | x) =`],
    [`两类的权重都是 0，无法判定`, `Both class weights are 0; no decision is possible`, `Beide Klassengewichte sind 0; keine Entscheidung möglich`],
    [`判为垃圾邮件`, `classified as spam`, `als Spam klassifiziert`],
    [`判为非垃圾邮件`, `classified as non-spam`, `als Nicht-Spam klassifiziert`],
    [`训练集里没有出现过这种输入`, `This input does not occur in the training set`, `Diese Eingabe kommt im Trainingssatz nicht vor`],
    [`　　S = 垃圾，N = 非垃圾`, `  S = spam, N = non-spam`, `  S = Spam, N = Nicht-Spam`],
    [`S = 垃圾，N = 非垃圾`, `S = spam, N = non-spam`, `S = Spam, N = Nicht-Spam`],
    [`先验`, `prior`, `Prior`],
    [`合计：后验几率`, `total: posterior odds`, `Summe: Posterior-Odds`],
    [`← 非垃圾`, `← non-spam`, `← Nicht-Spam`],
    [`垃圾 →`, `spam →`, `Spam →`],
    [`0/0（无定义）`, `0/0 (undefined)`, `0/0 (nicht definiert)`],
    [`（无证据）`, `(no evidence)`, `(keine Evidenz)`],
    [`似然比`, `likelihood ratio`, `Likelihood-Verhältnis`],
    [`词`, `word`, `Wort`],
    [`垃圾里出现`, `present in spam`, `in Spam vorhanden`],
    [`非垃圾里出现`, `present in non-spam`, `in Nicht-Spam vorhanden`],
    [`出现时`, `when present`, `wenn vorhanden`],
    [`不出现时`, `when absent`, `wenn nicht vorhanden`],
    [`P(垃圾 | x)`, `P(spam | x)`, `P(Spam | x)`],
    [`训练邮件`, `training emails`, `Trainings-E-Mails`],
    [`无`, `none`, `keine`],
    [`行`, `row`, `Zeile`],
    [`标签`, `label`, `Klasse`],
    [`判定`, `decision`, `Entscheidung`],
    [`判错`, `misclassified`, `falsch klassifiziert`],
    [`删除第`, `delete row `, `Zeile löschen: `],
    [`输入`, `input`, `Eingabe`],
    [`出现的词`, `words present`, `vorhandene Wörter`],
    [`直接数频率（垃圾 / 总数）`, `direct frequency (spam / total)`, `direkte Häufigkeit (Spam / gesamt)`],
    [`（都没有）`, `(none)`, `(keine)`],
    [`四个词都没有`, `none of the four words`, `keines der vier Wörter`],
    [`无法判定`, `undetermined`, `unbestimmt`],
    [`0/0，无法估计`, `0/0, cannot estimate`, `0/0, nicht schätzbar`],
    [`动手试`, `Try it`, `Ausprobieren`],
    [`当前训练表`, `Current training table`, `Aktuelle Trainingstabelle`],
    [`160 条合成语料`, `160 synthetic documents`, `160 synthetische Dokumente`],
    [`垃圾 / 支持数`, `spam / support`, `Spam / Beobachtungen`],
    [`后验均值`, `posterior mean`, `Posterior-Mittelwert`],
    [`95% 区间`, `95% interval`, `95-%-Intervall`],
    [`P(垃圾 | 这些词同时出现)`, `P(spam | these words co-occur)`, `P(Spam | diese Wörter treten gemeinsam auf)`],
    [`均值`, `mean`, `Mittelwert`],
    [`后验`, `posterior`, `Posterior`],
    [`▲ 频率 k/n`, `▲ frequency k/n`, `▲ Häufigkeit k/n`],
    [`朴素贝叶斯`, `Naive Bayes`, `Naive Bayes`],
    [`成对交互`, `pairwise interactions`, `Paarinteraktionen`],
    [`全表`, `full table`, `vollständige Tabelle`],
    [`训练样本数 n`, `training sample size n`, `Trainingsstichprobe n`],
    [`期望 KL（nat）`, `expected KL (nats)`, `erwartete KL (Nat)`],
    [`最低`, `lowest`, `niedrigster Wert`],
    [`真后验`, `true posterior`, `wahrer Posterior`],
    [`朴素贝叶斯的极限`, `Naive Bayes limit`, `Grenzwert von Naive Bayes`],
    [`成对交互的极限`, `pairwise-interaction limit`, `Grenzwert der Paarinteraktionen`],
    [`当前显示：`, `Currently shown:`, `Aktuell angezeigt:`],
    [`垃圾类 alternative × medicine`, `spam: alternative × medicine`, `Spam: alternative × medicine`],
    [`非垃圾类 medicine × basketball`, `non-spam: medicine × basketball`, `Nicht-Spam: medicine × basketball`],
    [`垃圾类三元交互`, `spam three-way interaction`, `Dreifachinteraktion in Spam`],
    [`重复次数`, `repetitions`, `Wiederholungen`],
    [`换一个随机种子重跑`, `Rerun with a new random seed`, `Mit neuem Zufalls-Seed erneut ausführen`],
    [`交互全设为 0（条件独立成立）`, `Set all interactions to 0 (conditional independence)`, `Alle Interaktionen auf 0 setzen (bedingte Unabhängigkeit)`],
    [`恢复默认`, `Restore defaults`, `Standardwerte wiederherstellen`],
    [`关注的符号`, `Focus symbol`, `Betrachtetes Symbol`],
    [`让一阶链生成一条同样长的序列`, `Generate an equal-length sequence from a first-order chain`, `Gleich lange Folge aus einer Kette erster Ordnung erzeugen`],
    [`恢复题目序列`, `Restore problem sequence`, `Aufgabenfolge wiederherstellen`],
    [`add-α 的 α`, `α for add-α`, `α für add-α`],
    [`插值的 τ`, `interpolation τ`, `Interpolationsparameter τ`],
    [`Kneser–Ney 的 D`, `Kneser–Ney D`, `Kneser–Ney D`],
    [`检验`, `test`, `Test`],
    [`统计量`, `statistic`, `Statistik`],
    [`自助 p 值`, `bootstrap p-value`, `Bootstrap-p-Wert`],
    [`少于两段`, `fewer than two runs`, `weniger als zwei Läufe`],
    [`方差`, `variance`, `Varianz`],
    [`似然比：1 阶对 2 阶`, `Likelihood ratio: order 1 vs 2`, `Likelihood-Verhältnis: Ordnung 1 vs. 2`],
    [`似然比：1 阶对 3 阶`, `Likelihood ratio: order 1 vs 3`, `Likelihood-Verhältnis: Ordnung 1 vs. 3`],
    [`固定阶数`, `fixed order`, `feste Ordnung`],
    [`多层记忆`, `multilevel memory`, `mehrstufiges Gedächtnis`],
    [`bit / 符号`, `bits / symbol`, `Bit / Symbol`],
    [`均匀`, `uniform`, `gleichverteilt`],
    [`当前是题目的序列`, `Current sequence is the problem sequence`, `Aktuelle Folge entspricht der Aufgabenfolge`],
    [`当前序列与题目不同`, `Current sequence differs from the problem`, `Aktuelle Folge weicht von der Aufgabe ab`],
    [`概率`, `probability`, `Wahrscheinlichkeit`],
    [`无数据`, `no data`, `keine Daten`],
    [`次数`, `count`, `Anzahl`],
    [`6(a) 转移矩阵`, `6(a) Transition matrix`, `6(a) Übergangsmatrix`],
    [`马尔可夫假设不成立`, `The Markov assumption fails`, `Die Markov-Annahme gilt nicht`],
    [`证据有多强`, `Strength of the evidence`, `Stärke der Evidenz`],
    [`记忆深度的代价`, `Cost of memory depth`, `Kosten der Gedächtnistiefe`],
    [`困惑度`, `perplexity`, `Perplexität`],
    [`〈句末〉`, `〈end of sentence〉`, `〈Satzende〉`],
    [`〈句首〉`, `〈start of sentence〉`, `〈Satzanfang〉`],
    [`没见过这个上文`, `context not observed`, `Kontext nicht beobachtet`],
    [`不看上文`, `no context`, `kein Kontext`],
    [`记忆层`, `memory level`, `Gedächtnisebene`],
    [`上文 h`, `context h`, `Kontext h`],
    [`出现次数 C(h)`, `count C(h)`, `Anzahl C(h)`],
    [`权重 λ(h)`, `weight λ(h)`, `Gewicht λ(h)`],
    [`这一层见过的下一个词（次数）`, `next words observed at this level (counts)`, `auf dieser Ebene beobachtete Folgewörter (Anzahlen)`],
    [`支持度插值`, `support interpolation`, `Evidenzinterpolation`],
    [`3 阶 add-α`, `order-3 add-α`, `add-α dritter Ordnung`],
    [`已读入的句子数`, `sentences processed`, `verarbeitete Sätze`],
    [`此后全是垃圾邮件`, `all subsequent messages are spam`, `danach nur noch Spam`],
    [`该段真实频率`, `true segment frequency`, `wahre Abschnittshäufigkeit`],
    [`全部`, `all`, `alle`],
    [`遗忘系数 ρ`, `forgetting factor ρ`, `Vergessensfaktor ρ`],
    [`^（句首）`, `^ (sentence start)`, `^ (Satzanfang)`],
    [`上下文没见过`, `unseen context`, `ungesehener Kontext`],
    [`概率为 0`, `probability 0`, `Wahrscheinlichkeit 0`],
    [`全部词合计 = 句长`, `sum over all words = sentence length`, `Summe über alle Wörter = Satzlänge`],
    [`吸收链 N 的 <BOS> 行`, `<BOS> row of absorbing-chain N`, `<BOS>-Zeile der absorbierenden Kette N`],
    [`语料里每句平均次数`, `mean count per sentence in corpus`, `mittlere Anzahl pro Satz im Korpus`],
    [`更长的记忆不一定更好`, `Longer memory is not always better`, `Längeres Gedächtnis ist nicht immer besser`],
    [`不平滑更糟`, `No smoothing is worse`, `Ohne Glättung ist es schlechter`],
    [`按支持度加权`, `Weight by support`, `Nach Evidenz gewichten`],
    [`横轴：第 1 维　纵轴：第 2 维　横线处第 2 维为 0`, `horizontal: dimension 1 · vertical: dimension 2 · line: dimension 2 = 0`, `horizontal: Dimension 1 · vertikal: Dimension 2 · Linie: Dimension 2 = 0`],
    [`出现次数`, `count`, `Anzahl`],
    [`P(出现 | 垃圾)`, `P(present | spam)`, `P(vorhanden | Spam)`],
    [`P(出现 | 非垃圾)`, `P(present | non-spam)`, `P(vorhanden | Nicht-Spam)`],
    [`对数似然比`, `log likelihood ratio`, `Log-Likelihood-Verhältnis`],
    [`请输入至少一个英文单词。`, `Enter at least one English word.`, `Geben Sie mindestens ein englisches Wort ein.`],
    [`已删除`, `deleted`, `gelöscht`],
    [`最可能的整条路径`, `most likely complete path`, `wahrscheinlichster vollständiger Pfad`],
    [`这句话里的词都在词表内。`, `Every word in this sentence is in the vocabulary.`, `Alle Wörter in diesem Satz sind im Vokabular enthalten.`],
    [`删掉词表外的词之后没有剩下可算的位置。`, `No positions remain after deleting out-of-vocabulary words.`, `Nach dem Löschen der Wörter außerhalb des Vokabulars bleiben keine berechenbaren Positionen.`],
    [`现在每一列只用到它左边的词，句子后半的信息还没传回来。`, `Each column now uses only words to its left; information from the second half of the sentence has not yet propagated back.`, `Jede Spalte verwendet jetzt nur Wörter links von ihr; die Information aus der zweiten Satzhälfte ist noch nicht zurückgelaufen.`],
    [`最后一行是 Viterbi 路径，它使整条状态序列的联合概率最大，和逐列取最大不一定相同。`, `The final row is the Viterbi path. It maximizes the joint probability of the complete state sequence and need not equal the columnwise maxima.`, `Die letzte Zeile ist der Viterbi-Pfad. Er maximiert die gemeinsame Wahrscheinlichkeit der vollständigen Zustandsfolge und muss nicht den spaltenweisen Maxima entsprechen.`],
    [`状态`, `state`, `Zustand`],
    [`最常发射的词`, `most frequent emissions`, `häufigste Emissionen`],
    [`起始`, `initial`, `Start`],
    [`促销开头`, `promotion opening`, `Werbeeinstieg`],
    [`促销收尾`, `promotion closing`, `Werbeabschluss`],
    [`伤病医疗`, `injury and medicine`, `Verletzung und Medizin`],
    [`体育`, `sports`, `Sport`],
    [`保留与删除的差别`, `Keeping versus deleting`, `Behalten gegenüber Löschen`],
    [`同一个词，不同的状态`, `Same word, different state`, `Dasselbe Wort, anderer Zustand`],
    [`前向与后向`, `Forward and backward`, `Vorwärts und rückwärts`],
    [`代码里的校验`, `Checks in the code`, `Prüfungen im Code`],
    [`✓ 通过`, `✓ pass`, `✓ bestanden`],
    [`✗ 失败`, `✗ fail`, `✗ fehlgeschlagen`],
    [`核心实现（原样摘自源码）`, `Core implementation (verbatim from source)`, `Kernimplementierung (unverändert aus dem Quellcode)`],

    // Names and descriptions stored in the injected result JSON.
    [`均匀编码 log₂3`, `uniform code log₂3`, `Gleichverteilungscode log₂3`],
    [`0 阶 + add-α`, `order 0 + add-α`, `Ordnung 0 + add-α`],
    [`1 阶 + add-α`, `order 1 + add-α`, `Ordnung 1 + add-α`],
    [`2 阶 + add-α`, `order 2 + add-α`, `Ordnung 2 + add-α`],
    [`3 阶 + add-α`, `order 3 + add-α`, `Ordnung 3 + add-α`],
    [`4 阶 + add-α`, `order 4 + add-α`, `Ordnung 4 + add-α`],
    [`支持度插值 τ=0.5`, `support interpolation τ=0.5`, `Evidenzinterpolation τ=0,5`],
    [`支持度插值 τ=2`, `support interpolation τ=2`, `Evidenzinterpolation τ=2`],
    [`支持度插值 τ=10`, `support interpolation τ=10`, `Evidenzinterpolation τ=10`],
    [`朴素贝叶斯：权重与后验`, `Naive Bayes: weights and posterior`, `Naive Bayes: Gewichte und Posterior`],
    [`支持度插值：证据越多越信长上下文`, `Support interpolation: trust longer contexts when evidence grows`, `Evidenzinterpolation: längeren Kontexten bei mehr Evidenz stärker vertrauen`],
    [`Kneser–Ney 递归`, `Kneser–Ney recursion`, `Kneser–Ney-Rekursion`],
    [`HMM forward–backward（带缩放）`, `HMM forward–backward (scaled)`, `HMM Forward–Backward (skaliert)`],
    [`OOV 的发射似然`, `Emission likelihood for OOV words`, `Emissions-Likelihood für OOV-Wörter`],
    [`吸收链：期望访问次数等于每句平均词频，期望句长等于平均句长`, `Absorbing chain: expected visits equal mean word counts per sentence; expected and mean sentence lengths agree`, `Absorbierende Kette: Erwartete Besuche entsprechen den mittleren Wortzahlen pro Satz; erwartete und mittlere Satzlänge stimmen überein`],
    [`模拟：无限数据下 全表 0 < 成对 < 朴素贝叶斯`, `Simulation: with unlimited data, full table 0 < pairwise < Naive Bayes`, `Simulation: Bei unbegrenzten Daten gilt vollständige Tabelle 0 < paarweise < Naive Bayes`],
    [`Baum–Welch 的目标函数单调不减`, `The Baum–Welch objective never decreases`, `Die Baum–Welch-Zielfunktion nimmt nie ab`],
    [`Beta 分布：CDF 与分位数对照闭式解`, `Beta distribution: CDF and quantiles match closed forms`, `Beta-Verteilung: CDF und Quantile stimmen mit geschlossenen Formen überein`],
    [`衰减计数：ρ=1 时等于一次性统计`, `Decayed counts equal batch counts when ρ=1`, `Vergessende Zählungen entsprechen bei ρ=1 der Batch-Zählung`],
    [`PPMI 对称非负；SVD 向量有限；medicinal 的最近邻是 medicine`, `PPMI is symmetric and nonnegative; SVD vectors are finite; medicinal's nearest neighbor is medicine`, `PPMI ist symmetrisch und nichtnegativ; SVD-Vektoren sind endlich; der nächste Nachbar von medicinal ist medicine`],
    [`forward–backward 与枚举全部 K^T 条路径的结果相等（20 个随机 HMM）`, `Forward–backward matches enumeration of all K^T paths (20 random HMMs)`, `Forward–Backward stimmt mit der Aufzählung aller K^T Pfade überein (20 zufällige HMMs)`],
    [`HMM 四个状态的名字与学到的高频词相符`, `The four HMM state names match their learned high-frequency words`, `Die Namen der vier HMM-Zustände passen zu den gelernten häufigen Wörtern`],
    [`第 5 题：(b) 3/35、(c) 2/5 为精确分数`, `Problem 5: (b) 3/35 and (c) 2/5 are exact fractions`, `Aufgabe 5: (b) 3/35 und (c) 2/5 sind exakte Brüche`],
    [`组合记忆：alternative+medicine 为 2/2，后验均值 3/4`, `Conjunction memory: alternative+medicine is 2/2 with posterior mean 3/4`, `Kombinationsgedächtnis: alternative+medicine ist 2/2 mit Posterior-Mittelwert 3/4`],
    [`第 5 题：各词的对数证据之和等于 logit 后验；medicine 一项恒为 0`, `Problem 5: word-level log evidence sums to the posterior logit; medicine contributes 0`, `Aufgabe 5: Die Wortbeiträge zur Log-Evidenz summieren sich zum Posterior-Logit; medicine trägt 0 bei`],
    [`第 5 题：8 个条件概率与手写值相等（4/5, 2/5, 2/5, 1/5 与 1/5, 3/5, 2/5, 4/5）`, `Problem 5: all 8 conditional probabilities match the handwritten values`, `Aufgabe 5: Alle 8 bedingten Wahrscheinlichkeiten stimmen mit den handschriftlichen Werten überein`],
    [`第 5 题：训练集覆盖 7/16 格；朴素贝叶斯判错第 1、8 封`, `Problem 5: the training set covers 7/16 cells; Naive Bayes misclassifies emails 1 and 8`, `Aufgabe 5: Der Trainingssatz deckt 7/16 Felder ab; Naive Bayes klassifiziert E-Mails 1 und 8 falsch`],
    [`第 5 题：16 种输入的后验与前文表格逐项一致`, `Problem 5: posteriors for all 16 inputs match the reference table`, `Aufgabe 5: Die Posteriorwerte aller 16 Eingaben stimmen mit der Referenztabelle überein`],
    [`第 5 题：16 个权重之和等于先验，两类合计为 1`, `Problem 5: the 16 weights sum to each prior, and both classes sum to 1`, `Aufgabe 5: Die 16 Gewichte summieren sich zu jedem Prior; beide Klassen zusammen ergeben 1`],
    [`第 6 题：† 的 6 段游程长度全为 3；3 阶上下文决定下一个符号`, `Problem 6: all 6 runs of † have length 3; an order-3 context determines the next symbol`, `Aufgabe 6: Alle 6 Läufe von † haben Länge 3; ein Kontext dritter Ordnung bestimmt das nächste Symbol`],
    [`第 6 题：转移矩阵与手写分数逐项相等`, `Problem 6: the transition matrix matches the handwritten fractions entry by entry`, `Aufgabe 6: Die Übergangsmatrix stimmt elementweise mit den handschriftlichen Brüchen überein`],
    [`add-α、支持度插值、Kneser–Ney 在见过和没见过的上下文上都归一`, `add-α, support interpolation, and Kneser–Ney are normalized on seen and unseen contexts`, `add-α, Evidenzinterpolation und Kneser–Ney sind für gesehene und ungesehene Kontexte normiert`],
    [`第 6 题：游程离散度检验拒绝一阶链（p < 0.001）；通用 G² 检验功效低；真正的一阶链不被拒绝`, `Problem 6: the run-dispersion test rejects a first-order chain (p < 0.001); the general G² test has low power; a true first-order chain is not rejected`, `Aufgabe 6: Der Lauf-Dispersions-Test verwirft eine Kette erster Ordnung (p < 0,001); der allgemeine G²-Test hat geringe Power; eine echte Kette erster Ordnung wird nicht verworfen`],
    [`OOV 保留位置：后验等于对未知词求和（多走一步转移），与删除它的结果不同`, `Keeping an OOV position marginalizes over the unknown word (one extra transition) and differs from deleting it`, `Das Behalten einer OOV-Position marginalisiert über das unbekannte Wort (ein zusätzlicher Übergang) und unterscheidet sich vom Löschen`],
    [`模拟：真分布只有成对交互时，成对模型能精确恢复`, `Simulation: the pairwise model exactly recovers a pairwise-only truth`, `Simulation: Das paarweise Modell rekonstruiert eine rein paarweise Wahrheit exakt`],
    [`子词相似把 medicinal 拉向“伤病医疗”；xyzzy 没有可用子词时保持中性`, `Subword similarity moves medicinal toward “injury and medicine”; xyzzy remains neutral without usable subwords`, `Subwortähnlichkeit verschiebt medicinal in Richtung „Verletzung und Medizin“; xyzzy bleibt ohne nutzbare Subwörter neutral`],
    [`支持度插值：τ→0 退化为精确记忆，τ→∞ 退化为 unigram`, `Support interpolation tends to exact memory as τ→0 and to a unigram as τ→∞`, `Evidenzinterpolation geht für τ→0 in exaktes Gedächtnis und für τ→∞ in ein Unigramm über`],
    [`模拟用的向量化朴素贝叶斯与逐项实现一致`, `The vectorized Naive Bayes used in simulation matches the itemwise implementation`, `Das vektorisierte Naive Bayes der Simulation stimmt mit der elementweisen Implementierung überein`],
    [`Viterbi 与枚举得到的最优路径相同`, `Viterbi matches the best path found by enumeration`, `Viterbi stimmt mit dem durch Aufzählung gefundenen besten Pfad überein`]
  ];

  const TEMPLATES = [
    [`{0} 封邮件`, `{0} emails`, `{0} E-Mails`],
    [`，已改动（最多 20 封）`, `, edited (maximum 20)`, `, bearbeitet (höchstens 20)`],
    [`，与题目一致`, `, matches the problem`, `, entspricht der Aufgabe`],
    [`训练集里这种输入有 {0} 封，其中垃圾 {1} 封`, `The training set contains {0} emails with this input, {1} of them spam`, `Der Trainingssatz enthält {0} E-Mails mit dieser Eingabe, davon {1} Spam`],
    [`输入 {0}，后验 {1}`, `input {0}, posterior {1}`, `Eingabe {0}, Posterior {1}`],
    [`{0} 封，垃圾 {1}`, `{0} emails, {1} spam`, `{0} E-Mails, {1} Spam`],
    [`第 {0} 行标签，点击切换`, `row {0} label; click to toggle`, `Klasse in Zeile {0}; zum Umschalten klicken`],
    [`第 {0} 行 {1}，点击切换`, `row {0}, {1}; click to toggle`, `Zeile {0}, {1}; zum Umschalten klicken`],
    [`删除第 {0} 行`, `delete row {0}`, `Zeile {0} löschen`],
    [`当前训练表（{0} 封）`, `Current training table ({0} emails)`, `Aktuelle Trainingstabelle ({0} E-Mails)`],
    [`恰好观察到 {0} 的概率：真实 p = 0.5 时 {1}，p = 0.7 时 {2}，p = 0.9 时 {3}。这几个数差得越小，这次观察越分不清它们。`, `Probability of observing exactly {0}: {1} when true p = 0.5, {2} when p = 0.7, and {3} when p = 0.9. The closer these values are, the less this observation can distinguish the probabilities.`, `Wahrscheinlichkeit, genau {0} zu beobachten: {1} bei wahrem p = 0,5, {2} bei p = 0,7 und {3} bei p = 0,9. Je ähnlicher diese Werte sind, desto schlechter unterscheidet die Beobachtung die Wahrscheinlichkeiten.`],
    [`输入 {0}`, `input {0}`, `Eingabe {0}`],
    [`这种输入的概率`, `probability of this input`, `Wahrscheinlichkeit dieser Eingabe`],
    [`正在浏览器里模拟：{0}/{1} 个样本量…`, `Simulating in the browser: {0}/{1} sample sizes…`, `Simulation im Browser: {0}/{1} Stichprobengrößen…`],
    [`浏览器内模拟，每个样本量重复 {0} 次，随机种子 {1}`, `Browser simulation, {0} repetitions per sample size, random seed {1}`, `Browser-Simulation, {0} Wiederholungen je Stichprobengröße, Zufalls-Seed {1}`],
    [`预先用 Python 算好的结果，每个样本量重复 {0} 次`, `Precomputed Python result, {0} repetitions per sample size`, `Mit Python vorab berechnetes Ergebnis, {0} Wiederholungen je Stichprobengröße`],
    [`序列里没有以 {0} 为当前符号的转移。`, `The sequence has no transition with {0} as the current symbol.`, `Die Folge enthält keinen Übergang mit {0} als aktuellem Symbol.`],
    [`往前看 {0} 个符号`, `look back {0} symbols`, `{0} Symbole zurückblicken`],
    [`前面是 {0}`, `preceded by {0}`, `vorangegangen ist {0}`],
    [`下一个是 {0}`, `next is {0}`, `als Nächstes kommt {0}`],
    [`序列里没有 {0}，或者它只出现在末尾。`, `The sequence contains no {0}, or it occurs only at the end.`, `Die Folge enthält kein {0}, oder es steht nur am Ende.`],
    [`长度 {0}`, `length {0}`, `Länge {0}`],
    [`{0} 段`, `{0} runs`, `{0} Läufe`],
    [`连续 {0} 的个数`, `number of consecutive {0}`, `Anzahl aufeinanderfolgender {0}`],
    [`{0} 阶 + add-α`, `order {0} + add-α`, `Ordnung {0} + add-α`],
    [`固定阶数（α = {0}）`, `fixed order (α = {0})`, `feste Ordnung (α = {0})`],
    [`支持度插值 τ={0}`, `support interpolation τ={0}`, `Evidenzinterpolation τ={0}`],
    [`多层记忆（最长看 3 个）`, `multilevel memory (up to 3 symbols)`, `mehrstufiges Gedächtnis (bis zu 3 Symbole)`],
    [`铭文序列（{0} 个符号，点一个符号可以改）`, `Inscription sequence ({0} symbols; click one to change it)`, `Inschriftfolge ({0} Symbole; zum Ändern auf ein Symbol klicken)`],
    [`{0} 之后是什么，取决于往前看几个`, `What follows {0} depends on how far back we look`, `Was auf {0} folgt, hängt von der Rückblicktiefe ab`],
    [`{0} 连续段的长度`, `Lengths of {0} runs`, `Längen der {0}-Läufe`],
    [`第 {0} 个符号 {1}，点击更换`, `symbol {0}: {1}; click to change`, `Symbol {0}: {1}; zum Ändern klicken`],
    [`前 {0} 个词`, `previous {0} words`, `vorherige {0} Wörter`],
    [`多层记忆（最长看 3 个词）`, `multilevel memory (up to 3 words)`, `mehrstufiges Gedächtnis (bis zu 3 Wörter)`],
    [`下一个词是 {0}`, `next word: {0}`, `nächstes Wort: {0}`],
    [`第 {0} 句之后`, `after sentence {0}`, `nach Satz {0}`],
    [`约 {0} 句`, `about {0} sentences`, `etwa {0} Sätze`],
    [`ρ = {0}，有效记忆{1}`, `ρ = {0}, effective memory: {1}`, `ρ = {0}, effektives Gedächtnis: {1}`],
    [`{0} 阶`, `order {0}`, `Ordnung {0}`],
    [`{0} 阶最大似然`, `order-{0} maximum likelihood`, `Maximum Likelihood der Ordnung {0}`],
    [`第 {0} 位 “{1}”`, `position {0}: “{1}”`, `Position {0}: „{1}“`],
    [`{0} 发射 {1}`, `{0} emits {1}`, `{0} emittiert {1}`],
    [`检查项：{0} 项全部通过`, `Checks: all {0} passed`, `Prüfungen: alle {0} bestanden`],
    [`检查项：{0}/{1} 通过`, `Checks: {0}/{1} passed`, `Prüfungen: {0}/{1} bestanden`],

    // Complete, variable-bearing findings and explanatory notes.
    [`四个词有 16 种组合，训练集只出现过 {0} 种。直接数频率时另外 {1} 种是 0/0。`, `The four words define 16 combinations; the training set contains only {0}. Direct frequency estimation leaves the other {1} as 0/0.`, `Die vier Wörter ergeben 16 Kombinationen; der Trainingssatz enthält nur {0}. Bei direkter Häufigkeitsschätzung bleiben die übrigen {1} als 0/0.`],
    [`朴素贝叶斯能给 16 种输入全部打分，但判错两封训练邮件，正是同时含 alternative 和 medicine 的那两封。`, `Naive Bayes scores all 16 inputs, but misclassifies two training emails—the two containing both alternative and medicine.`, `Naive Bayes bewertet alle 16 Eingaben, klassifiziert jedoch zwei Trainings-E-Mails falsch: genau die beiden mit alternative und medicine.`],
    [`第 6 题里 † 的 {0} 段都恰好是三个。在一阶链下，这件事的概率只有这么大。`, `In Problem 6, all {0} runs of † have length three. Under a first-order chain, the probability of this event is only the value shown.`, `In Aufgabe 6 haben alle {0} Läufe von † die Länge drei. Unter einer Kette erster Ordnung ist dieses Ereignis nur so wahrscheinlich wie der angezeigte Wert.`],
    [`没见过的句子上，3 阶 add-α 的困惑度比 1 阶还高；Kneser–Ney 把它降到这个数。`, `On unseen sentences, order-3 add-α has higher perplexity than order 1; Kneser–Ney reduces it to the value shown.`, `Auf ungesehenen Sätzen hat add-α dritter Ordnung eine höhere Perplexität als erster Ordnung; Kneser–Ney senkt sie auf den angezeigten Wert.`],
    [`{0}　　S = 垃圾，N = 非垃圾`, `{0}  S = spam, N = non-spam`, `{0}  S = Spam, N = Nicht-Spam`],
    [`×{0}（无证据）`, `×{0} (no evidence)`, `×{0} (keine Evidenz)`],
    [`{0} 封邮件，与题目一致`, `{0} emails, matches the problem`, `{0} E-Mails, entspricht der Aufgabe`],
    [`{0} 封邮件，已改动（最多 20 封）`, `{0} emails, edited (maximum 20)`, `{0} E-Mails, bearbeitet (höchstens 20)`],
    [`直接估计 P(垃圾 | x) 要给 16 种输入各配一个参数，每个参数只能用落在那一格的邮件。10 封邮件只覆盖了 {0} 格，其余 {1} 格没有任何数据。朴素贝叶斯改成每类估 4 个伯努利参数，10 封邮件都用得上。`, `A direct estimate of P(spam | x) assigns one parameter to each of 16 inputs, and each parameter can use only the emails in its own cell. The 10 emails cover only {0} cells, leaving {1} with no data. Naive Bayes instead estimates four Bernoulli parameters per class, so all 10 emails contribute.`, `Eine direkte Schätzung von P(Spam | x) weist jeder der 16 Eingaben einen Parameter zu; jeder Parameter kann nur die E-Mails in seinem Feld verwenden. Die 10 E-Mails decken nur {0} Felder ab, {1} bleiben ohne Daten. Naive Bayes schätzt stattdessen vier Bernoulli-Parameter je Klasse, sodass alle 10 E-Mails beitragen.`],
    [`输入 {0}：w_S = {1}，w_N = {2}，P(垃圾 | x) = {3}，判为非垃圾。`, `Input {0}: w_S = {1}, w_N = {2}, P(spam | x) = {3}; classified as non-spam.`, `Eingabe {0}: w_S = {1}, w_N = {2}, P(Spam | x) = {3}; als Nicht-Spam klassifiziert.`],
    [`输入 {0}：P(垃圾 | x) = {1}，判为非垃圾。训练集里同时含 alternative 和 medicine 的邮件有两封（第 {2} 行），都是垃圾，朴素贝叶斯两封都判错。它把两个词分开计分，“一起出现”这条信息用不上。`, `Input {0}: P(spam | x) = {1}; classified as non-spam. The training set has two emails containing both alternative and medicine (rows {2}); both are spam and Naive Bayes misclassifies both. It scores the words separately and cannot use their co-occurrence.`, `Eingabe {0}: P(Spam | x) = {1}; als Nicht-Spam klassifiziert. Der Trainingssatz enthält zwei E-Mails mit alternative und medicine (Zeilen {2}); beide sind Spam und werden von Naive Bayes falsch klassifiziert. Das Modell bewertet die Wörter getrennt und kann ihr gemeinsames Auftreten nicht nutzen.`],
    [`在两类里都是 {0}，似然比恒为 1。所以 16 格里只差 medicine 的两格数值相同，这个词对分类没有贡献。`, `has probability {0} in both classes, so its likelihood ratio is always 1. Consequently, pairs of the 16 cells differing only in medicine have identical values; this word contributes nothing to classification.`, `hat in beiden Klassen die Wahrscheinlichkeit {0}; sein Likelihood-Verhältnis ist daher immer 1. Folglich haben Paare der 16 Felder, die sich nur in medicine unterscheiden, denselben Wert; dieses Wort trägt nichts zur Klassifikation bei.`],
    [`在训练表里把第 9 行的 medicine 改成 ✓，medicine 的似然比就不再是 1。在最大似然下删掉几封邮件，很快会出现等于 0 的参数，有些输入变成 0/0，这就是需要平滑的原因。`, `Change medicine in row 9 of the training table to ✓ and its likelihood ratio is no longer 1. Under maximum likelihood, deleting only a few emails quickly creates zero-valued parameters and makes some inputs 0/0—why smoothing is needed.`, `Setzen Sie medicine in Zeile 9 der Trainingstabelle auf ✓; dann ist sein Likelihood-Verhältnis nicht mehr 1. Beim Maximum-Likelihood-Ansatz erzeugt schon das Löschen weniger E-Mails Nullparameter und macht einige Eingaben zu 0/0 — deshalb ist Glättung nötig.`],
    [`均值 {0}`, `mean {0}`, `Mittelwert {0}`],
    [`第 5 题里 alternative 和 medicine 同时出现的两封都是垃圾：频率 {0}，后验均值 {1}，95% 区间 {2} 到 {3}。合成语料里 {4} 是 {5}，均值 {6}，区间 {7} 到 {8}。两者的频率都是 100%，区间宽度差了将近十倍。`, `In Problem 5, both emails containing alternative and medicine are spam: frequency {0}, posterior mean {1}, and 95% interval {2} to {3}. In the synthetic corpus, {4} is {5}, with mean {6} and interval {7} to {8}. Both frequencies are 100%, yet the interval widths differ by almost a factor of ten.`, `In Aufgabe 5 sind beide E-Mails mit alternative und medicine Spam: Häufigkeit {0}, Posterior-Mittelwert {1}, 95-%-Intervall {2} bis {3}. Im synthetischen Korpus gilt für {4}: {5}, Mittelwert {6}, Intervall {7} bis {8}. Beide Häufigkeiten sind 100 %, doch die Intervallbreiten unterscheiden sich fast um den Faktor zehn.`],
    [`在全部样本量上都是{0}的损失最低。`, `{0} has the lowest loss at every sample size.`, `{0} hat bei jeder Stichprobengröße den kleinsten Verlust.`],
    [`n ≤ {0} 时{1}的损失最低；n 从 {2} 到 {3} 时{4}的损失最低；n ≥ {5} 时{6}的损失最低。`, `For n ≤ {0}, {1} has the lowest loss; from n = {2} to {3}, {4} has the lowest loss; for n ≥ {5}, {6} has the lowest loss.`, `Für n ≤ {0} hat {1} den kleinsten Verlust; von n = {2} bis {3} hat {4} den kleinsten Verlust; für n ≥ {5} hat {6} den kleinsten Verlust.`],
    [`当前设定下条件独立成立，朴素贝叶斯没有偏差，数据越多越准。`, `Under the current settings conditional independence holds, so Naive Bayes is unbiased and improves with more data.`, `Unter den aktuellen Einstellungen gilt bedingte Unabhängigkeit; Naive Bayes ist daher unverzerrt und wird mit mehr Daten genauer.`],
    [`朴素贝叶斯的曲线在 {0} 处走平，数据再多也降不下去。这是条件独立假设带来的偏差。`, `The Naive Bayes curve levels off at {0}; more data cannot lower it. This is bias from the conditional-independence assumption.`, `Die Naive-Bayes-Kurve flacht bei {0} ab; mehr Daten senken sie nicht weiter. Das ist der Bias der Annahme bedingter Unabhängigkeit.`],
    [`真分布里没有三元交互，成对交互模型没有偏差。全表同样没有偏差，但每一格都要靠自己的数据，起步最慢。`, `The true distribution has no three-way interaction, so the pairwise model is unbiased. The full table is also unbiased, but each cell needs its own data and learns most slowly at first.`, `Die wahre Verteilung enthält keine Dreifachinteraktion; das paarweise Modell ist daher unverzerrt. Auch die vollständige Tabelle ist unverzerrt, doch jedes Feld benötigt eigene Daten und lernt anfangs am langsamsten.`],
    [`成对交互模型走平在 {0}，因为真分布里有一项三元交互它表达不了。全表没有结构假设，偏差为 0，但每一格都要靠自己的数据，起步最慢。`, `The pairwise model levels off at {0} because it cannot express the true distribution's three-way interaction. The full table has no structural assumption and zero bias, but each cell needs its own data and learns most slowly at first.`, `Das paarweise Modell flacht bei {0} ab, weil es die Dreifachinteraktion der wahren Verteilung nicht darstellen kann. Die vollständige Tabelle hat keine Strukturannahme und Bias 0, doch jedes Feld benötigt eigene Daten und lernt anfangs am langsamsten.`],
    [`一阶链里 {0} 接 {1} 的概率是 {2}，段长服从几何分布。{3} 段全是 {4} 个，单段恰为 {5} 的概率是 {6}，{7} 段都如此的概率约 {8}。`, `In a first-order chain, P({1} after {0}) = {2}, so run lengths are geometric. All {3} runs have length {4}; one run has exactly length {5} with probability {6}, and all {7} do so with probability about {8}.`, `In einer Kette erster Ordnung gilt P({1} nach {0}) = {2}; die Lauflängen sind daher geometrisch. Alle {3} Läufe haben Länge {4}; ein Lauf hat mit Wahrscheinlichkeit {6} genau Länge {5}, alle {7} mit Wahrscheinlichkeit etwa {8}.`],
    [`一阶链里 {0} 接 {1} 的概率是 {2}，段长服从几何分布。这条序列里 {3} 的 {4} 段长度是 {5}。`, `In a first-order chain, P({1} after {0}) = {2}, so run lengths are geometric. In this sequence, the {4} runs of {3} have lengths {5}.`, `In einer Kette erster Ordnung gilt P({1} nach {0}) = {2}; die Lauflängen sind daher geometrisch. In dieser Folge haben die {4} Läufe von {3} die Längen {5}.`],
    [`{0} 的各段长度过于整齐（方差 ≤ 观察值）`, `Runs of {0} are unusually uniform (variance ≤ observed)`, `Die Läufe von {0} sind ungewöhnlich gleichmäßig (Varianz ≤ beobachtet)`],
    [`方差 {0}`, `variance {0}`, `Varianz {0}`],
    [`做法：按当前序列拟合一阶链，用它生成 {0} 条同样长的序列，看统计量有多少次不输给观察值。p 值小说明一阶链很难产生这样的序列。`, `Method: fit a first-order chain to the current sequence, generate {0} equal-length sequences, and count how often the statistic is at least as extreme as observed. A small p-value means such a sequence is hard for a first-order chain to produce.`, `Methode: Eine Kette erster Ordnung an die aktuelle Folge anpassen, {0} gleich lange Folgen erzeugen und zählen, wie oft die Statistik mindestens so extrem wie beobachtet ist. Ein kleiner p-Wert bedeutet, dass eine solche Folge für eine Kette erster Ordnung schwer zu erzeugen ist.`],
    [`均匀 {0}`, `uniform {0}`, `gleichverteilt {0}`],
    [`按“当前符号 → 下一个符号”数 36 次转移，每行归一化，得到 * 行 ({0})、□ 行 ({1})、† 行 ({2})。`, `Count the 36 transitions as “current symbol → next symbol” and normalize each row, giving row * ({0}), row □ ({1}), and row † ({2}).`, `Die 36 Übergänge werden als „aktuelles Symbol → nächstes Symbol“ gezählt und jede Zeile normiert. Es ergeben sich Zeile * ({0}), Zeile □ ({1}) und Zeile † ({2}).`],
    [`一阶假设说“下一个只看当前”，那么当前是 † 时下一个是 † 的概率应当恒为 {0}。实际上 † 只连了一个或两个时，下一个 {1} 次里 {2} 次是 †；已经连了三个时，{3} 次里 {4} 次是 †。下一个符号取决于 † 已经连了几个，至少要 3 阶才能描述。`, `The first-order assumption says “the next symbol depends only on the current one,” so after † the probability of † should always be {0}. In fact, after a run of only one or two † symbols, {2} of the next {1} symbols are †; after three, {4} of {3} are †. The next symbol depends on the current run length, requiring at least order 3.`, `Die Annahme erster Ordnung besagt: „Das nächste Symbol hängt nur vom aktuellen ab.“ Nach † sollte die Wahrscheinlichkeit für † daher stets {0} sein. Tatsächlich sind nach nur einem oder zwei †-Symbolen {2} der nächsten {1} Symbole †; nach drei sind es {4} von {3}. Das nächste Symbol hängt von der aktuellen Lauflänge ab und erfordert mindestens Ordnung 3.`],
    [`一阶链里单段恰为 3 的概率是 {0}，{1} 段都是 3 的概率约 {2}。这个数针对的是看过数据之后才注意到的模式，偏乐观。更公平的问法是“各段长度这么整齐”有多罕见：{3} 条模拟序列里只有 {4} 条做到，p ≈ {5}。不针对任何模式的似然比检验就弱得多：1 阶对 3 阶 p ≈ {6}，1 阶对 2 阶 p ≈ {7}。37 个符号撑不起高阶模型的那么多参数。`, `In a first-order chain, one run has length exactly 3 with probability {0}, and all {1} runs do so with probability about {2}. Because this pattern was noticed after seeing the data, that figure is optimistic. A fairer question asks how rare such uniform run lengths are: only {4} of {3} simulated sequences match them, p ≈ {5}. An untargeted likelihood-ratio test is much weaker: order 1 vs 3 gives p ≈ {6}, and order 1 vs 2 gives p ≈ {7}. Thirty-seven symbols cannot support all the parameters of a high-order model.`, `In einer Kette erster Ordnung hat ein Lauf mit Wahrscheinlichkeit {0} genau Länge 3; alle {1} Läufe tun dies mit Wahrscheinlichkeit etwa {2}. Da das Muster erst nach Sichtung der Daten auffiel, ist diese Zahl optimistisch. Fairer ist die Frage, wie selten so gleichmäßige Lauflängen sind: Nur {4} von {3} simulierten Folgen erreichen dies, p ≈ {5}. Ein ungerichteter Likelihood-Ratio-Test ist deutlich schwächer: Ordnung 1 gegen 3 liefert p ≈ {6}, Ordnung 1 gegen 2 p ≈ {7}. Für die vielen Parameter eines Modells höherer Ordnung reichen 37 Symbole nicht aus.`],
    [`逐符号预测时，3 阶是 {0} bit，低于均匀编码的 {1}；1 阶是 {2}，反而更高。37 个符号太少，3 阶的优势只有 {3} bit。把 τ 拖到 0.5，插值的码长升到 {4}，它把只见过一两次的上下文当成了定论。`, `For sequential prediction, order 3 uses {0} bits, below the uniform code's {1}; order 1 uses {2}, which is higher. With only 37 symbols, order 3 gains just {3} bits. Setting τ to 0.5 raises the interpolated code length to {4} because contexts seen once or twice are treated as conclusive.`, `Bei sequenzieller Vorhersage benötigt Ordnung 3 {0} Bit, weniger als der Gleichverteilungscode mit {1}; Ordnung 1 benötigt dagegen {2}. Bei nur 37 Symbolen beträgt der Vorteil dritter Ordnung lediglich {3} Bit. Wird τ auf 0,5 gesetzt, steigt die interpolierte Codelänge auf {4}, weil ein- oder zweimal beobachtete Kontexte als endgültig behandelt werden.`],
    [`点“让一阶链生成一条”，† 的段长会变得参差不齐，三个检验的 p 值通常也都变大。这才是无记忆的序列该有的样子。`, `Click “Generate an equal-length sequence from a first-order chain.” The † run lengths become irregular and all three p-values usually increase—what a memoryless sequence should look like.`, `Klicken Sie auf „Gleich lange Folge aus einer Kette erster Ordnung erzeugen“. Die †-Lauflängen werden unregelmäßig und alle drei p-Werte steigen gewöhnlich — so sollte eine gedächtnislose Folge aussehen.`],
    [`语料有 {0} 条，其中不同的句子只有 {1} 个。随机划分会让测试句原样出现在训练集里，测到的只是背诵。这里按句子分组做 {2} 折，测试句都是训练时没见过的。下面三个平滑参数同时作用于预测器和困惑度。`, `The corpus has {0} documents but only {1} distinct sentences. A random split would copy test sentences into training and measure memorization. Here sentences are grouped for {2}-fold validation, so every test sentence is unseen during training. The three smoothing parameters below affect both the predictor and perplexity.`, `Das Korpus enthält {0} Dokumente, aber nur {1} verschiedene Sätze. Eine zufällige Aufteilung würde Testsätze unverändert ins Training kopieren und nur Auswendiglernen messen. Hier werden Sätze für eine {2}-fache Validierung gruppiert, sodass jeder Testsatz im Training ungesehen ist. Die drei Glättungsparameter unten wirken sowohl auf den Prädiktor als auch auf die Perplexität.`],
    [`语料重排成前 {0} 条非垃圾、后 {1} 条垃圾，句首是 miracle 的频率从 {2} 跳到 {3}。不遗忘时估计停在 {4}，接近两段的平均 {5}；ρ = {6} 时最后是 {7}。ρ 越小跟得越快，但能用的句子越少，曲线越抖。`, `The corpus is reordered into {0} non-spam documents followed by {1} spam documents; the frequency of miracle at sentence start jumps from {2} to {3}. Without forgetting, the estimate ends at {4}, near the two-segment average {5}; with ρ = {6}, it ends at {7}. Smaller ρ adapts faster but uses fewer effective sentences, making the curve noisier.`, `Das Korpus wird in {0} Nicht-Spam- und danach {1} Spam-Dokumente umgeordnet; die Häufigkeit von miracle am Satzanfang springt von {2} auf {3}. Ohne Vergessen endet die Schätzung bei {4}, nahe dem Mittel der beiden Abschnitte {5}; bei ρ = {6} endet sie bei {7}. Ein kleineres ρ passt sich schneller an, nutzt aber effektiv weniger Sätze und macht die Kurve unruhiger.`],
    [`<EOS> 设为吸收态，N = (I − Q)⁻¹ 的 <BOS> 行是每个词在一句里的期望出现次数。两列逐项相等（最大差 {0}），这是最大似然转移矩阵的恒等式，可以拿来校验实现。`, `Treating <EOS> as absorbing, the <BOS> row of N = (I − Q)⁻¹ gives the expected number of occurrences of every word in a sentence. The two columns agree entry by entry (maximum difference {0}); this identity of the maximum-likelihood transition matrix verifies the implementation.`, `Mit <EOS> als absorbierendem Zustand gibt die <BOS>-Zeile von N = (I − Q)⁻¹ die erwartete Anzahl jedes Wortes pro Satz an. Beide Spalten stimmen elementweise überein (maximale Differenz {0}); diese Identität der Maximum-Likelihood-Übergangsmatrix prüft die Implementierung.`],
    [`阶数从 1 加到 3，add-α 的困惑度从 {0} 升到 {1}。上下文越长，见过的次数越少，均匀先验就把更多概率摊给全部 {2} 个词。`, `Increasing the order from 1 to 3 raises add-α perplexity from {0} to {1}. Longer contexts have fewer observations, so the uniform prior spreads more probability across all {2} words.`, `Die Erhöhung der Ordnung von 1 auf 3 steigert die add-α-Perplexität von {0} auf {1}. Längere Kontexte werden seltener beobachtet, sodass der Gleichverteilungs-Prior mehr Wahrscheinlichkeit auf alle {2} Wörter verteilt.`],
    [`3 阶最大似然在测试集上有 {0} 的词上下文从未出现，另有 {1} 被判为概率 0。`, `Under order-3 maximum likelihood, {0} of test-word contexts are unseen and another {1} are assigned probability 0.`, `Beim Maximum-Likelihood-Modell dritter Ordnung sind {0} der Testwortkontexte ungesehen; weiteren {1} wird Wahrscheinlichkeit 0 zugewiesen.`],
    [`上面的公式让每层上下文的权重随它出现的次数增长。它等价于一个 Dirichlet 后验预测：先验均值是短一阶的分布，先验强度是 τ 个伪观测。τ = 0.5 时困惑度 {0}，τ = 2 时 {1}，τ = 10 时 {2}。τ 太小等于相信只见过一两次的上下文。`, `The formula above increases each context level's weight with its support. It is a Dirichlet posterior predictive distribution whose prior mean is the next-shorter distribution and whose prior strength is τ pseudo-observations. Perplexity is {0} at τ = 0.5, {1} at τ = 2, and {2} at τ = 10. A very small τ overtrusts contexts seen only once or twice.`, `Die obige Formel erhöht das Gewicht jeder Kontextebene mit ihrer Evidenz. Sie entspricht einer Dirichlet-Posterior-Prädiktivverteilung: Der Prior-Mittelwert ist die nächstkürzere Verteilung, die Prior-Stärke beträgt τ Pseudobeobachtungen. Die Perplexität ist {0} bei τ = 0,5, {1} bei τ = 2 und {2} bei τ = 10. Ein sehr kleines τ vertraut Kontexten zu stark, die nur ein- oder zweimal beobachtet wurden.`],
    [`默认折扣下困惑度 {0}，是这里最低的。它从每个计数里扣掉固定的 D 留给回退，低阶分布按“这个词出现在多少种不同的上文之后”来计数。`, `With the default discount, perplexity is {0}, the lowest here. A fixed D is removed from each count and reserved for backoff; the lower-order distribution counts how many distinct contexts precede each word.`, `Mit dem Standard-Discount beträgt die Perplexität {0}, der niedrigste Wert hier. Von jeder Zählung wird ein festes D für den Backoff abgezogen; die Verteilung niedrigerer Ordnung zählt, nach wie vielen verschiedenen Kontexten ein Wort auftritt.`],
    [`在预测器里输入“xyzzy medicine”：三词上文没见过，权重 λ 为 0，预测自动退回到“medicine”这一层。把 τ 拖小，长上文的权重变大，没见过的句子上困惑度随之变差。`, `Enter “xyzzy medicine” in the predictor: the three-word context is unseen, so its weight λ is 0 and prediction automatically backs off to the “medicine” level. Reducing τ increases the weight of long contexts and worsens perplexity on unseen sentences.`, `Geben Sie „xyzzy medicine“ in den Prädiktor ein: Der Dreiwortkontext ist ungesehen, sein Gewicht λ ist 0, und die Vorhersage fällt automatisch auf die Ebene „medicine“ zurück. Ein kleineres τ erhöht das Gewicht langer Kontexte und verschlechtert die Perplexität auf ungesehenen Sätzen.`],
    [`“{0}”不在词表里。它的 {1} 个字符片段中有 {2} 个在词表词里出现过（覆盖率 {3}%），例如 {4}。向量取这些片段的平均，余弦最近的词：{5}。`, `“{0}” is outside the vocabulary. Of its {1} character fragments, {2} occur in vocabulary words ({3}% coverage), for example {4}. Its vector averages those fragments; nearest words by cosine similarity: {5}.`, `„{0}“ liegt außerhalb des Vokabulars. Von seinen {1} Zeichenfragmenten kommen {2} in Vokabularwörtern vor ({3} % Abdeckung), zum Beispiel {4}. Sein Vektor mittelt diese Fragmente; nächste Wörter nach Kosinusähnlichkeit: {5}.`],
    [`“{0}”不在词表里，它的字符片段也没有一个在词表词里出现过，所以得不到向量。`, `“{0}” is outside the vocabulary and none of its character fragments occurs in a vocabulary word, so no vector can be formed.`, `„{0}“ liegt außerhalb des Vokabulars; keines seiner Zeichenfragmente kommt in einem Vokabularwort vor, daher kann kein Vektor gebildet werden.`],
    [`“{0}”在词表里。8 维向量上余弦最近的词：{1}。图上用细线连着。`, `“{0}” is in the vocabulary. Its nearest words by cosine similarity in the 8-dimensional space are {1}; thin lines connect them in the plot.`, `„{0}“ ist im Vokabular. Seine nächsten Wörter nach Kosinusähnlichkeit im 8-dimensionalen Raum sind {1}; dünne Linien verbinden sie im Diagramm.`],
    [`第 {0} 维`, `dimension {0}`, `Dimension {0}`],
    [`旧 ZIP 里 HMM 的转移和发射概率是手填的。这里用同样的种子词做初值，再用 Baum–Welch 在 160 条语料上训练，{0} 轮收敛。训练后四个状态的含义变了，所以按它们实际学到的高频词重新起名：{1}。`, `The old ZIP used hand-entered HMM transition and emission probabilities. Here the same seed words initialize Baum–Welch training on 160 documents, which converges in {0} iterations. The four states change meaning after training, so they are renamed from the high-frequency words they actually learned: {1}.`, `Im alten ZIP wurden die HMM-Übergangs- und Emissionswahrscheinlichkeiten von Hand eingetragen. Hier initialisieren dieselben Startwörter ein Baum–Welch-Training auf 160 Dokumenten, das nach {0} Iterationen konvergiert. Die vier Zustände ändern dabei ihre Bedeutung und werden nach den tatsächlich gelernten häufigen Wörtern benannt: {1}.`],
    [`删除了 {0}。它两边的词变成直接相邻，中间少了一步转移。`, `Deleted {0}. Its neighbors become adjacent, removing one transition between them.`, `{0} wurde gelöscht. Seine Nachbarn werden direkt benachbart; dazwischen entfällt ein Übergang.`],
    [`{0}：{1}% 的字符片段在词表里出现过，最像 {2}。`, `{0}: {1}% of its character fragments occur in the vocabulary; it is most similar to {2}.`, `{0}: {1} % der Zeichenfragmente kommen im Vokabular vor; am ähnlichsten ist es {2}.`],
    [`{0}：没有任何字符片段在词表里出现过，不提供词面证据，后验只来自上下文。`, `{0}: no character fragment occurs in the vocabulary, so it supplies no lexical evidence and its posterior comes only from context.`, `{0}: Kein Zeichenfragment kommt im Vokabular vor; daher liefert es keine lexikalische Evidenz und sein Posterior stammt nur aus dem Kontext.`],
    [`{0}：不提供词面证据，后验只来自上下文。`, `{0}: supplies no lexical evidence, so its posterior comes only from context.`, `{0}: liefert keine lexikalische Evidenz; sein Posterior stammt nur aus dem Kontext.`],
    [`{0}：不提供词面证据，后验只来自上下文。 最后一行是 Viterbi 路径，它使整条状态序列的联合概率最大，和逐列取最大不一定相同。`, `{0}: supplies no lexical evidence, so its posterior comes only from context. The final row is the Viterbi path; it maximizes the joint probability of the complete state sequence and need not equal the columnwise maxima.`, `{0}: liefert keine lexikalische Evidenz; sein Posterior stammt nur aus dem Kontext. Die letzte Zeile ist der Viterbi-Pfad. Er maximiert die gemeinsame Wahrscheinlichkeit der vollständigen Zustandsfolge und muss nicht den spaltenweisen Maxima entsprechen.`],
    [`→ {0}`, `→ {0}`, `→ {0}`],
    [`“{0}”：保留 xyzzy 的位置时，cure 属于“促销收尾”的后验是 {1}；删掉 xyzzy 后是 {2}。保留位置等于对未知词求和，链多走了一步，有更多机会离开“促销开头”。`, `“{0}”: keeping xyzzy's position gives cure posterior {1} for “promotion closing”; deleting xyzzy gives {2}. Keeping the position marginalizes over the unknown word and adds one transition, creating more opportunity to leave “promotion opening.”`, `„{0}“: Wird die Position von xyzzy behalten, hat cure für „Werbeabschluss“ den Posterior {1}; nach dem Löschen von xyzzy sind es {2}. Das Behalten der Position marginalisiert über das unbekannte Wort und fügt einen Übergang hinzu, sodass „Werbeeinstieg“ eher verlassen werden kann.`],
    [`“{0}”里 medicine 属于“{1}”的后验是 {2}`, `In “{0}”, medicine has posterior {2} for “{1}”`, `In „{0}“ hat medicine für „{1}“ den Posterior {2}`],
    [`“{0}”里 medicine 属于“{1}”的后验是 {2}；“{3}”里 medicine 属于“{4}”的后验是 {5}。词是同一个，区别全在上下文。`, `In “{0}”, medicine has posterior {2} for “{1}”; in “{3}”, it has posterior {5} for “{4}”. The word is the same; the difference is entirely contextual.`, `In „{0}“ hat medicine für „{1}“ den Posterior {2}; in „{3}“ hat es für „{4}“ den Posterior {5}. Das Wort ist dasselbe; der Unterschied liegt vollständig im Kontext.`],
    [`。词是同一个，区别全在上下文。`, `. The word is the same; the difference is entirely contextual.`, `. Das Wort ist dasselbe; der Unterschied liegt vollständig im Kontext.`],
    [`选“只看前文”，再输入“xyzzy xyzzy money”：前两列只能给出起始分布推出来的猜测；切回“整句”，末尾的 money 把前面的未知词一起拉向促销状态。这就是后向传递带回来的信息。`, `Choose “past only” and enter “xyzzy xyzzy money”: the first two columns can only guess from the initial distribution. Switch back to “full sentence” and the final money pulls the preceding unknown words toward a promotion state. This is the information carried backward.`, `Wählen Sie „nur vorheriger Kontext“ und geben Sie „xyzzy xyzzy money“ ein: Die ersten beiden Spalten können nur aus der Anfangsverteilung schätzen. Nach dem Wechsel zurück zu „ganzer Satz“ zieht das abschließende money die vorherigen unbekannten Wörter in Richtung eines Werbezustands. Diese Information wird rückwärts übertragen.`],
    [`forward–backward 的结果与枚举全部状态路径的结果逐项相等；Baum–Welch 的目标函数每一轮都不下降。`, `Forward–backward matches enumeration of all state paths entry by entry; the Baum–Welch objective never decreases between iterations.`, `Forward–Backward stimmt elementweise mit der Aufzählung aller Zustandspfade überein; die Baum–Welch-Zielfunktion nimmt von Iteration zu Iteration nie ab.`]
  ];

  const PHRASES = [
    [`正在浏览器里模拟…`, `Simulating in the browser…`, `Simulation im Browser…`],
    [`一阶链预期`, `expected under first-order chain`, `unter Kette erster Ordnung erwartet`],
    [`〈句末〉`, `〈end of sentence〉`, `〈Satzende〉`],
    [`〈句首〉`, `〈start of sentence〉`, `〈Satzanfang〉`],
    [`促销开头`, `promotion opening`, `Werbeeinstieg`],
    [`促销收尾`, `promotion closing`, `Werbeabschluss`],
    [`伤病医疗`, `injury and medicine`, `Verletzung und Medizin`],
    [`体育`, `sports`, `Sport`],
    [`下一 个`, `next`, `nächstes`],
    [`下一步`, `next step`, `nächster Schritt`]
  ];

  const exact = new Map(ROWS.map(row => [row[0], row]));
  const escapeRegExp = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const compiled = TEMPLATES.map(row => {
    const ids = [];
    const pattern = row[0].split(/(\{\d+\})/).map(part => {
      const m = /^\{(\d+)\}$/.exec(part);
      if (!m) return escapeRegExp(part);
      ids.push(+m[1]);
      return '(.*?)';
    }).join('');
    return { row, ids, specificity: row[0].replace(/\{\d+\}/g, '').length, re: new RegExp('^' + pattern + '$', 'u') };
  }).sort((a, b) => b.specificity - a.specificity);

  let language = 'en';
  const originalText = new WeakMap();
  const originalAttrs = new WeakMap();
  const index = () => language === 'de' ? 2 : 1;

  function translateCore(source) {
    if (source == null) return source;
    const raw = String(source);
    if (!/[\u3400-\u9fff]/u.test(raw)) return raw;
    const leading = raw.match(/^\s*/u)[0];
    const trailing = raw.match(/\s*$/u)[0];
    const core = raw.slice(leading.length, raw.length - trailing.length);
    const hit = exact.get(core);
    if (hit) {
      const translated = hit[index()];
      return (translated === '.' ? '' : leading) + translated + trailing;
    }
    for (const item of compiled) {
      const match = item.re.exec(core);
      if (!match) continue;
      const values = {};
      item.ids.forEach((id, i) => { values[id] = translateCore(match[i + 1]); });
      const rendered = item.row[index()].replace(/\{(\d+)\}/g, (_, id) => values[+id] ?? '');
      return leading + rendered + trailing;
    }
    let out = core;
    for (const row of PHRASES.sort((a, b) => b[0].length - a[0].length)) out = out.split(row[0]).join(row[index()]);
    return leading + out + trailing;
  }

  function setText(element, source) {
    element.textContent = translateCore(source);
    if (element.firstChild && element.firstChild.nodeType === Node.TEXT_NODE) originalText.set(element.firstChild, String(source));
    return element;
  }

  function translateAttribute(element, name) {
    let attrs = originalAttrs.get(element);
    if (!attrs) { attrs = {}; originalAttrs.set(element, attrs); }
    if (!(name in attrs)) attrs[name] = element.getAttribute(name);
    const source = attrs[name];
    if (source != null) {
      const translated = translateCore(source);
      if (element.getAttribute(name) !== translated) element.setAttribute(name, translated);
    }
  }

  function translateTree(root) {
    if (!root) return;
    if (root.nodeType === Node.TEXT_NODE) {
      const parent = root.parentElement;
      if (!parent || parent.closest('script,style,pre,code')) return;
      if (!originalText.has(root)) originalText.set(root, root.nodeValue);
      const translated = translateCore(originalText.get(root));
      if (root.nodeValue !== translated) root.nodeValue = translated;
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) return;
    const base = root.nodeType === Node.DOCUMENT_NODE ? root.documentElement : root;
    if (base.nodeType === Node.ELEMENT_NODE) ['aria-label', 'title', 'placeholder'].forEach(name => {
      if (base.hasAttribute(name)) translateAttribute(base, name);
    });
    const walker = document.createTreeWalker(base, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.nodeType === Node.TEXT_NODE) {
        const parent = node.parentElement;
        if (!parent || parent.closest('script,style,pre,code')) continue;
        if (!originalText.has(node)) originalText.set(node, node.nodeValue);
        const translated = translateCore(originalText.get(node));
        if (node.nodeValue !== translated) node.nodeValue = translated;
      } else {
        ['aria-label', 'title', 'placeholder'].forEach(name => {
          if (node.hasAttribute(name)) translateAttribute(node, name);
        });
      }
    }
  }

  function applyLanguage(next, fromUser) {
    language = next === 'de' ? 'de' : 'en';
    document.documentElement.lang = language;
    document.title = language === 'de' ? 'Labor zur Gedächtnisträgheit' : 'Memory Inertia Lab';
    document.querySelectorAll('[data-language]').forEach(button => {
      const active = button.dataset.language === language;
      button.setAttribute('aria-pressed', String(active));
    });
    const group = document.querySelector('.language-switch');
    if (group) group.setAttribute('aria-label', language === 'de' ? 'Sprache' : 'Language');
    translateTree(document);
    try { localStorage.setItem('memlab-language', language); } catch (_) {}
    if (fromUser && window.__memlab && typeof window.__memlab.relocalize === 'function') {
      window.__memlab.relocalize();
      translateTree(document);
    }
  }

  try { language = localStorage.getItem('memlab-language') === 'de' ? 'de' : 'en'; } catch (_) {}
  window.__memlabI18n = {
    get language() { return language; },
    text: translateCore,
    setText,
    translateTree,
    applyLanguage
  };

  document.querySelectorAll('[data-language]').forEach(button => {
    button.addEventListener('click', () => applyLanguage(button.dataset.language, true));
  });
  applyLanguage(language, false);

  const observer = new MutationObserver(records => {
    for (const record of records) {
      for (const node of record.addedNodes) translateTree(node);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
