"""Recompute everything, write the tables, and build the self-contained HTML report.

    python run_all.py
"""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import pipeline  # noqa: E402

OUT = ROOT / "outputs"
TABLES = OUT / "tables"


def write_csv(name, header, rows):
    with open(TABLES / name, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def write_tables(R):
    h5, h6, co, sim, hm = R["hw5"], R["hw6"], R["corpus"], R["sim"], R["hmm"]
    write_csv("hw5_16_states.csv",
              ["miracle,alternative,medicine,basketball", "w_spam", "w_not_spam", "P(spam|x)", "decimal",
               "class", "training_emails", "training_spam"],
              [[s["x"], s["w_spam"], s["w_not"], s["post"], f"{s['post_f']:.4f}",
                "spam" if s["label"] else "not spam", s["n"], s["k"]] for s in h5["states"]])
    write_csv("hw5_conjunction_memory.csv",
              ["words", "support_n", "spam_k", "MLE", "Beta(1,1)_posterior_mean", "ci95_low", "ci95_high"],
              [["+".join(c["features"]), c["n"], c["k"], c["mle"], c["post_mean"],
                f"{c['lo']:.4f}", f"{c['hi']:.4f}"] for c in h5["conjunctions"]])
    write_csv("hw6_transition_matrix.csv", ["from"] + h6["alphabet"],
              [[a] + row for a, row in zip(h6["alphabet"], h6["probs"])])
    write_csv("hw6_contexts.csv", ["order", "context", "n"] + [f"next_{a}" for a in h6["alphabet"]],
              [[k, c["ctx"], c["n"]] + c["counts"] for k in (1, 2, 3) for c in h6["contexts"][k]])
    write_csv("hw6_prequential_bits.csv", ["model", "bits_per_symbol"],
              [[m["name"], f"{m['bits']:.4f}"] for m in h6["prequential"]])
    write_csv("learning_curves_excess_log_loss.csv", ["n"] + list(sim["curves"]),
              [[n] + [f"{sim['curves'][m][i]:.5f}" for m in sim["curves"]] for i, n in enumerate(sim["sizes"])])
    write_csv("corpus_language_models.csv", ["model", "grouped_5fold_perplexity"],
              [[m["name"], f"{m['ppl']:.3f}"] for m in co["lm"]])
    write_csv("word_table.csv", ["word", "count", "P(w|spam)", "P(w|not)", "log_odds", "svd_1", "svd_2"],
              [[w["w"], w["count"], f"{w['p_spam']:.4f}", f"{w['p_not']:.4f}", f"{w['log_odds']:.4f}",
                f"{w['x']:.4f}", f"{w['y']:.4f}"] for w in R["emb"]["words"]])
    write_csv("hmm_transition.csv", ["from"] + hm["state_keys"],
              [[k] + [f"{v:.4f}" for v in row] for k, row in zip(hm["state_keys"], hm["A"])])
    write_csv("hmm_emission.csv", ["word"] + hm["state_keys"],
              [[w] + [f"{hm['B'][k][i]:.5f}" for k in range(len(hm["state_keys"]))]
               for i, w in enumerate(hm["vocab"])])


SHELL = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
         '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
         '<style>body{margin:0}[hidden]{display:none!important}</style>\n</head>\n<body>\n%s\n</body>\n</html>\n')


def build_report(R, fragment_path=None):
    """outputs/report.html is a complete document that opens straight from disk.
    With --fragment PATH the same page is also written without the <html> shell
    (the form needed when a host supplies its own shell)."""
    template = (ROOT / "viz" / "template.html").read_text(encoding="utf-8")
    i18n = (ROOT / "viz" / "i18n.js").read_text(encoding="utf-8")
    payload = json.dumps(R, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    page = template.replace("/*__I18N__*/", i18n).replace("/*__RESULTS__*/null", payload)
    (OUT / "report.html").write_text(SHELL % page, encoding="utf-8")
    if fragment_path:
        Path(fragment_path).write_text(page, encoding="utf-8")


def run_checks():
    """Run the test suite and return [{name, description, ok}] for the report."""
    sys.path.insert(0, str(ROOT / "tests"))
    import test_all
    checks = []
    for name in sorted(n for n in dir(test_all) if n.startswith("test_")):
        try:
            getattr(test_all, name)()
            ok = True
        except Exception:
            ok = False
        checks.append({"name": name, "description": test_all.DESCRIPTIONS.get(name, name), "ok": ok})
    return checks


def main():
    TABLES.mkdir(parents=True, exist_ok=True)
    R = pipeline.build_results()
    R["checks"] = run_checks()
    (OUT / "results.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
    write_tables(R)
    fragment = sys.argv[sys.argv.index("--fragment") + 1] if "--fragment" in sys.argv else None
    build_report(R, fragment)

    h5, h6, co = R["hw5"], R["hw6"], R["corpus"]
    by = {s["x"]: s for s in h5["states"]}
    print("Problem 5  P(S|0011) =", by["0011"]["post"], " P(S|0110) =", by["0110"]["post"],
          f" training accuracy {h5['train_correct']}/10, observed cells {h5['observed_cells']}/16")
    print("Problem 6  transition matrix", h6["probs"])
    print("           P(all six dagger runs have length 3 | first-order chain) = %.2e" % h6["p_all_len3"])
    print("Corpus     grouped 5-fold perplexity:",
          ", ".join(f"{m['name']} {m['ppl']:.2f}" for m in co["lm"]))
    print("Checks     %d/%d passed" % (sum(c["ok"] for c in R["checks"]), len(R["checks"])))
    print("Wrote", OUT / "results.json", "and", len(list(TABLES.glob('*.csv'))), "tables",
          "+ report.html" if (OUT / "report.html").exists() else "")


if __name__ == "__main__":
    main()
