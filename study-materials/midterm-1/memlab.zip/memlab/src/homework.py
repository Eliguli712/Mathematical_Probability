"""Data transcribed from the problem sheet (problems 5 and 6).

Problem 5: ten e-mails, label + presence of four words.
Problem 6: the inscription with three symbols.
"""

WORDS = ("miracle", "alternative", "medicine", "basketball")

# (spam, (miracle, alternative, medicine, basketball)) -- row order as printed
EMAILS = [
    (1, (1, 1, 1, 1)),
    (0, (0, 0, 1, 1)),
    (1, (1, 0, 0, 0)),
    (0, (0, 1, 0, 0)),
    (1, (1, 0, 0, 0)),
    (0, (0, 1, 0, 1)),
    (1, (1, 0, 0, 0)),
    (1, (0, 1, 1, 0)),
    (0, (1, 1, 0, 1)),
    (0, (0, 0, 1, 1)),
]

X = [x for _, x in EMAILS]
Y = [y for y, _ in EMAILS]

# Problem 6.  The printed row is partly covered by pen circles; this reading is the
# one whose transition counts reproduce the handwritten matrix exactly
# (rows *, box, dagger: [0, 4/7, 3/7], [4/11, 4/11, 3/11], [1/6, 1/6, 2/3]).
SYMBOLS = "*□□□*†††*†††□†††□†††*□*□□*†††□□*□†††*"
ALPHABET = ("*", "□", "†")

# Test e-mails from parts (b) and (c), as (miracle, alternative, medicine, basketball)
QUERY_B = (0, 0, 1, 1)   # "I hurt my foot playing basketball. Can you get me some medicine?"
QUERY_C = (0, 1, 1, 0)   # "This alternative medicine is amazing, send us all your money!"
