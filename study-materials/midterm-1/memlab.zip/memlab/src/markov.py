"""Markov memory at several depths: n-gram counts, smoothing, interpolation whose weight
grows with support, Kneser-Ney, absorbing chains, and exponentially decayed counts."""
from collections import Counter, defaultdict
import math
import numpy as np

BOS, EOS = "<BOS>", "<EOS>"


def pad(tokens):
    return [BOS] + list(tokens) + [EOS]


# ---------- counting -------------------------------------------------------
class NGramCounts:
    """counts[k][h][w]: how often w followed the length-k context h (k = 0..K).

    cont[k][h][w] is the Kneser-Ney continuation count: the number of distinct tokens
    seen immediately to the left of (h, w), plus the occurrences of (h, w) that sit at
    the very start of a sequence and therefore have no left neighbour.
    """

    def __init__(self, K):
        self.K = K
        self.counts = [defaultdict(Counter) for _ in range(K + 1)]
        self._left = [defaultdict(lambda: defaultdict(set)) for _ in range(K + 1)]
        self._start = [defaultdict(Counter) for _ in range(K + 1)]

    def add(self, seq, first=0):
        """Count every position t >= first of seq as a prediction target."""
        for t in range(first, len(seq)):
            w = seq[t]
            for k in range(0, min(self.K, t) + 1):
                h = tuple(seq[t - k:t])
                self.counts[k][h][w] += 1
                if t - k - 1 >= 0:
                    self._left[k][h][w].add(seq[t - k - 1])
                else:
                    self._start[k][h][w] += 1
        return self

    def cont(self, k, h):
        c = Counter()
        for w, s in self._left[k].get(h, {}).items():
            c[w] += len(s)
        for w, n in self._start[k].get(h, {}).items():
            c[w] += n
        return c


def collect(seqs, K, first=0):
    nc = NGramCounts(K)
    for s in seqs:
        nc.add(s, first)
    return nc


def context_table(seq, k):
    """P(next | previous k symbols) as raw counts, for inspecting the Markov assumption."""
    table = defaultdict(Counter)
    for t in range(k, len(seq)):
        table[tuple(seq[t - k:t])][seq[t]] += 1
    return table


# ---------- predictive models ----------------------------------------------
class AddAlpha:
    """Fixed order k with a symmetric Dirichlet(alpha) prior:
    P(w | h) = (C(h, w) + alpha) / (C(h) + alpha V)."""

    def __init__(self, vocab, order, alpha=0.5):
        self.vocab, self.order, self.alpha = list(vocab), order, alpha
        self.K = order

    def fit(self, seqs, first=0):
        self.nc = collect(seqs, self.order, first)
        return self

    def prob(self, ctx, w):
        k = min(self.order, len(ctx))
        c = self.nc.counts[k].get(tuple(ctx[len(ctx) - k:]), Counter())
        return (c[w] + self.alpha) / (sum(c.values()) + self.alpha * len(self.vocab))


class SupportInterpolation:
    """Chain the orders 0..K, trusting each context in proportion to its support:

        lambda(h) = C(h) / (C(h) + tau)
        P_k(w | h) = lambda(h) * C(h, w) / C(h) + (1 - lambda(h)) * P_{k-1}(w | h')
                   = (C(h, w) + tau * P_{k-1}(w | h')) / (C(h) + tau)

    The second line shows it is a Dirichlet posterior predictive whose prior mean is the
    shorter-context distribution and whose prior strength is tau pseudo-observations."""

    def __init__(self, vocab, K, tau=10.0, alpha=0.5):
        self.vocab, self.K, self.tau, self.alpha = list(vocab), K, tau, alpha

    def fit(self, seqs, first=0):
        self.nc = collect(seqs, self.K, first)
        return self

    def prob(self, ctx, w, trace=None):
        c0 = self.nc.counts[0].get((), Counter())
        p = (c0[w] + self.alpha) / (sum(c0.values()) + self.alpha * len(self.vocab))
        if trace is not None:
            trace.append({"k": 0, "n": sum(c0.values()), "lambda": None, "p": p})
        for k in range(1, min(self.K, len(ctx)) + 1):
            c = self.nc.counts[k].get(tuple(ctx[len(ctx) - k:]), Counter())
            n = sum(c.values())
            p = (c[w] + self.tau * p) / (n + self.tau)
            if trace is not None:
                trace.append({"k": k, "n": n, "lambda": n / (n + self.tau), "p": p})
        return p


class KneserNey:
    """Interpolated Kneser-Ney with one absolute discount D.

    Highest order uses raw counts, lower orders use continuation counts:
        P(w | h) = max(c(h, w) - D, 0) / c(h) + D * N1+(h .) / c(h) * P(w | h')
    The recursion ends in the uniform distribution over the vocabulary."""

    def __init__(self, vocab, K, D=0.75):
        self.vocab, self.K, self.D = list(vocab), K, D

    def fit(self, seqs, first=0):
        self.nc = collect(seqs, self.K, first)
        return self

    def prob(self, ctx, w):
        k = min(self.K, len(ctx))
        return self._p(tuple(ctx[len(ctx) - k:]), w, top=True)

    def _p(self, h, w, top):
        k = len(h)
        lower = self._p(h[1:], w, False) if k else 1.0 / len(self.vocab)
        c = self.nc.counts[k].get(h, Counter()) if top else self.nc.cont(k, h)
        tot = sum(c.values())
        if tot == 0:
            return lower
        return max(c[w] - self.D, 0.0) / tot + self.D * len(c) / tot * lower


# ---------- evaluation -----------------------------------------------------
def prequential_bits(seq, make_model, K):
    """Predict each symbol from the symbols before it only (refit on the prefix),
    and return the mean code length in bits per symbol."""
    bits = []
    for t in range(len(seq)):
        model = make_model().fit([seq[:t]], first=0)
        p = model.prob(tuple(seq[max(0, t - K):t]), seq[t])
        bits.append(-math.log2(p))
    return float(np.mean(bits)), bits


def perplexity(model, padded_seqs, K):
    """exp(mean negative log-probability) over every token after <BOS>, <EOS> included."""
    lp, n = 0.0, 0
    for s in padded_seqs:
        for t in range(1, len(s)):
            lp += math.log(model.prob(tuple(s[max(0, t - K):t]), s[t]))
            n += 1
    return math.exp(-lp / n)


def mle_failures(train_padded, test_padded, k):
    """What the unsmoothed order-k estimate does on unseen text: the share of test tokens
    whose context never occurred (0/0) and whose continuation never occurred (probability 0)."""
    nc = collect(train_padded, k, first=1)
    unseen_ctx = zero = n = 0
    for s in test_padded:
        for t in range(1, len(s)):
            kk = min(k, t)
            c = nc.counts[kk].get(tuple(s[t - kk:t]), Counter())
            n += 1
            if sum(c.values()) == 0:
                unseen_ctx += 1
            elif c[s[t]] == 0:
                zero += 1
    return {"unseen_context": unseen_ctx / n, "zero_probability": zero / n, "tokens": n}


# ---------- runs -----------------------------------------------------------
def run_lengths(seq):
    """[(symbol, length), ...] for maximal blocks of a repeated symbol."""
    runs, prev, n = [], None, 0
    for s in seq:
        if s == prev:
            n += 1
        else:
            if prev is not None:
                runs.append((prev, n))
            prev, n = s, 1
    runs.append((prev, n))
    return runs


def geometric_run_pmf(p_stay, max_len):
    """Run-length law implied by a first-order chain: P(L = l) = p^(l-1) (1 - p)."""
    return [p_stay ** (l - 1) * (1 - p_stay) for l in range(1, max_len + 1)]


# ---------- absorbing chain ------------------------------------------------
def absorbing_chain(sentences):
    """First-order chain over <BOS> + words (transient) with <EOS> absorbing.

    Canonical form P = [[Q, R], [0, 1]].  N = (I - Q)^-1 holds the expected number of
    visits to each transient state before absorption."""
    vocab = sorted({w for s in sentences for w in s})
    states = [BOS] + vocab
    ix = {s: i for i, s in enumerate(states)}
    C = np.zeros((len(states), len(states)))
    r = np.zeros(len(states))
    for s in sentences:
        p = pad(s)
        for a, b in zip(p[:-1], p[1:]):
            if b == EOS:
                r[ix[a]] += 1
            else:
                C[ix[a], ix[b]] += 1
    tot = C.sum(1) + r
    Q, R = C / tot[:, None], r / tot
    N = np.linalg.inv(np.eye(len(states)) - Q)
    return {"states": states, "Q": Q, "R": R, "N": N,
            "expected_visits_from_bos": N[0],
            "expected_length": float(N[0, 1:].sum()),
            "absorption_prob_from_bos": float(N[0] @ R)}


# ---------- forgetting -----------------------------------------------------
def decayed_tracking(sentences, rho, target, alpha=0.5):
    """Online estimate of P_t(b | a) for target = (a, b) with exponentially decayed counts:
    C_t = rho * C_{t-1} + (transitions of sentence t).  Returns one estimate per sentence."""
    vocab = sorted({w for s in sentences for w in s} | {EOS})
    cols = {w: i for i, w in enumerate(vocab)}
    rows = {w: i for i, w in enumerate([BOS] + vocab)}
    C = np.zeros((len(rows), len(cols)))
    a, b = target
    out = []
    for s in sentences:
        C *= rho
        p = pad(s)
        for u, v in zip(p[:-1], p[1:]):
            C[rows[u], cols[v]] += 1.0
        row = C[rows[a]]
        out.append(float((row[cols[b]] + alpha) / (row.sum() + alpha * len(cols))))
    return out


# ---------- testing the order of a chain ------------------------------------
def order_log_likelihood(seq, k, start):
    """Maximised log-likelihood of positions t >= start under an order-k chain."""
    tab = defaultdict(Counter)
    for t in range(start, len(seq)):
        tab[tuple(seq[t - k:t])][seq[t]] += 1
    return sum(c * math.log(c / sum(cs.values())) for cs in tab.values() for c in cs.values())


def g2_statistic(seq, k0, k1):
    """Likelihood-ratio statistic 2 (LL_k1 - LL_k0) for nested orders k0 < k1,
    both evaluated on the same positions t >= k1."""
    return 2.0 * (order_log_likelihood(seq, k1, k1) - order_log_likelihood(seq, k0, k1))


def sample_first_order(seq, alphabet, n, rng):
    """A new sequence of length n from the first-order chain fitted to seq (same first symbol).
    A symbol that never occurs as a predecessor gets a uniform row."""
    tab = context_table(seq, 1)
    rows = {}
    for a in alphabet:
        c = np.array([tab[(a,)][b] for b in alphabet], dtype=float)
        rows[a] = c / c.sum() if c.sum() > 0 else np.full(len(alphabet), 1.0 / len(alphabet))
    out = [seq[0]]
    for _ in range(n - 1):
        out.append(alphabet[rng.choice(len(alphabet), p=rows[out[-1]])])
    return out


def markov_order_test(seq, alphabet, k1, B=5000, seed=6):
    """Parametric bootstrap test of H0: first-order chain, against order k1.
    Simulate B sequences from the fitted first-order chain and compare G^2."""
    rng = np.random.default_rng(seed)
    observed = g2_statistic(seq, 1, k1)
    sims = [g2_statistic(sample_first_order(seq, alphabet, len(seq), rng), 1, k1) for _ in range(B)]
    exceed = sum(s >= observed - 1e-12 for s in sims)
    return {"k1": k1, "g2": observed, "B": B, "exceed": int(exceed), "p": (exceed + 1) / (B + 1),
            "null_mean": float(np.mean(sims)), "null_q95": float(np.quantile(sims, 0.95))}


def simulate_first_order_batch(seq, alphabet, B, rng):
    """B sequences (as integer arrays, one per row) from the first-order chain fitted to seq."""
    tab = context_table(seq, 1)
    P = np.array([[tab[(a,)][b] for b in alphabet] for a in alphabet], dtype=float)
    tot = P.sum(1, keepdims=True)
    P = np.where(tot > 0, P / np.where(tot > 0, tot, 1), 1.0 / len(alphabet))
    cum = np.cumsum(P, axis=1)
    out = np.empty((B, len(seq)), dtype=int)
    out[:, 0] = alphabet.index(seq[0])
    for t in range(1, len(seq)):
        u = rng.random(B)
        out[:, t] = np.minimum((u[:, None] > cum[out[:, t - 1]]).sum(1), len(alphabet) - 1)
    return out


def run_length_variance(ids, symbol_id):
    """Population variance of the run lengths of one symbol; None with fewer than two runs."""
    runs, n = [], 0
    for v in ids:
        if v == symbol_id:
            n += 1
        elif n:
            runs.append(n)
            n = 0
    if n:
        runs.append(n)
    return float(np.var(runs)) if len(runs) >= 2 else None


def run_dispersion_test(seq, alphabet, symbol, B=20000, seed=6):
    """Under a first-order chain the run lengths of a symbol are geometric, hence dispersed.
    p = share of simulated first-order sequences whose run-length variance for `symbol`
    is as small as the observed one (sequences with fewer than two runs never count)."""
    sid = alphabet.index(symbol)
    observed = run_length_variance([alphabet.index(s) for s in seq], sid)
    sims = simulate_first_order_batch(seq, list(alphabet), B, np.random.default_rng(seed))
    stats = [run_length_variance(row, sid) for row in sims]
    hits = sum(1 for v in stats if v is not None and v <= observed + 1e-12)
    return {"symbol": symbol, "variance": observed, "B": B, "hits": hits, "p": (hits + 1) / (B + 1)}
