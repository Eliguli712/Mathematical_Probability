"""Conjunction ("pair") memory with Beta smoothing, and a bias-variance experiment
comparing three ways of estimating P(spam | x) for x in {0,1}^4."""
from fractions import Fraction
from itertools import combinations
import math
import numpy as np


# ---------- Beta posterior -------------------------------------------------
def beta_posterior_mean(k, n, a=1, b=1):
    return Fraction(k + a, n + a + b)


def log_beta_pdf(x, a, b):
    return ((a - 1) * math.log(x) + (b - 1) * math.log1p(-x)
            + math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b))


def _betacf(a, b, x, itmax=300, eps=1e-14):
    """Continued fraction for the incomplete beta function (Lentz's method)."""
    tiny = 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, itmax + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def beta_cdf(x, a, b):
    """Regularised incomplete beta function I_x(a, b)."""
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    front = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
                     + a * math.log(x) + b * math.log1p(-x))
    if x < (a + 1.0) / (a + b + 2.0):
        return front * _betacf(a, b, x) / a
    return 1.0 - front * _betacf(b, a, 1.0 - x) / b


def beta_quantile(q, a, b):
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if beta_cdf(mid, a, b) < q:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def beta_interval(k, n, a=1, b=1, level=0.95):
    """Equal-tailed credible interval of Beta(a + k, b + n - k)."""
    t = (1 - level) / 2
    return beta_quantile(t, a + k, b + n - k), beta_quantile(1 - t, a + k, b + n - k)


# ---------- conjunction memory ---------------------------------------------
def conjunction_memory(X, y, names, size=2, a=1, b=1):
    """For every set of `size` features: among e-mails containing all of them,
    support n, spam count k, MLE k/n and the Beta(a, b) posterior."""
    out = []
    for idx in combinations(range(len(names)), size):
        sel = [t for r, t in zip(X, y) if all(r[j] for j in idx)]
        n, k = len(sel), sum(sel)
        lo, hi = beta_interval(k, n, a, b)
        out.append({
            "features": [names[j] for j in idx],
            "n": n, "k": k,
            "mle": Fraction(k, n) if n else None,
            "post_mean": beta_posterior_mean(k, n, a, b),
            "ci95": (lo, hi),
        })
    return out


# ---------- bias-variance experiment ---------------------------------------
STATES = np.array([[(s >> (3 - j)) & 1 for j in range(4)] for s in range(16)])  # rows 0000..1111


def make_truth(p_spam=(0.8, 0.4, 0.4, 0.2), p_not=(0.2, 0.6, 0.4, 0.8),
               theta_ad_spam=2.0, theta_db_not=1.5, theta_mad_spam=-2.5):
    """A known generating distribution over (y, x) with the homework's word order
    (miracle, alternative, medicine, basketball).  Class-conditional independence is
    broken on purpose: alternative x medicine attract each other in spam,
    medicine x basketball in non-spam, plus one three-way term in spam so that even a
    pairwise model is slightly misspecified."""
    M, A, D, B = STATES.T

    def base(p):
        p = np.asarray(p)
        return (STATES * np.log(p) + (1 - STATES) * np.log(1 - p)).sum(1)

    ls = base(p_spam) + theta_ad_spam * A * D + theta_mad_spam * M * A * D
    ln = base(p_not) + theta_db_not * D * B
    px_s = np.exp(ls) / np.exp(ls).sum()
    px_n = np.exp(ln) / np.exp(ln).sum()
    joint = np.stack([0.5 * px_n, 0.5 * px_s])           # joint[y, state]
    px = joint.sum(0)
    return {"joint": joint, "px": px, "post": joint[1] / px}


def est_full_table(n_x, k_x):
    """Saturated model: one Beta(1,1)-smoothed parameter per cell."""
    return (k_x + 1.0) / (n_x + 2.0)


def est_naive_bayes(n_x, k_x):
    """Bernoulli naive Bayes with add-one smoothing, computed from cell counts."""
    cs, cn = k_x, n_x - k_x
    ns, nn = cs.sum(), cn.sum()
    ps = (cs @ STATES + 1.0) / (ns + 2.0)
    pn = (cn @ STATES + 1.0) / (nn + 2.0)
    ls = math.log((ns + 1.0) / (ns + nn + 2.0)) + STATES @ np.log(ps) + (1 - STATES) @ np.log(1 - ps)
    ln = math.log((nn + 1.0) / (ns + nn + 2.0)) + STATES @ np.log(pn) + (1 - STATES) @ np.log(1 - pn)
    return 1.0 / (1.0 + np.exp(ln - ls))


_PAIR_DESIGN = np.column_stack(
    [np.ones(16)] + [STATES[:, j] for j in range(4)]
    + [STATES[:, i] * STATES[:, j] for i, j in combinations(range(4), 2)]
).astype(float)                                           # 1 + 4 + 6 = 11 columns


def est_pairwise_logistic(n_x, k_x, ridge=1.0, iters=100):
    """Log-odds = intercept + 4 main effects + 6 pairwise interactions, ridge-penalised
    (penalty on everything except the intercept), fitted by Newton's method with
    step-halving so that every step increases the penalised log-likelihood."""
    Z = _PAIR_DESIGN
    pen = np.full(Z.shape[1], ridge)
    pen[0] = 0.0

    def objective(beta):
        eta = Z @ beta
        return float(k_x @ eta - n_x @ np.logaddexp(0.0, eta) - 0.5 * pen @ beta ** 2)

    beta = np.zeros(Z.shape[1])
    f = objective(beta)
    for _ in range(iters):
        mu = 1.0 / (1.0 + np.exp(-(Z @ beta)))
        grad = Z.T @ (k_x - n_x * mu) - pen * beta
        H = (Z * (n_x * mu * (1 - mu))[:, None]).T @ Z + np.diag(pen) + 1e-8 * np.eye(len(beta))
        step = np.linalg.solve(H, grad)
        t = 1.0
        while t > 1e-8 and objective(beta + t * step) < f:
            t *= 0.5
        beta = beta + t * step
        f_new = objective(beta)
        if f_new - f < 1e-12:
            break
        f = f_new
    return 1.0 / (1.0 + np.exp(-(Z @ beta)))


ESTIMATORS = {
    "full_table": est_full_table,
    "pairwise": est_pairwise_logistic,
    "naive_bayes": est_naive_bayes,
}


def excess_log_loss(truth, p_hat):
    """Expected KL divergence E_x[ KL( P(Y|x) || P_hat(Y|x) ) ] in nats, computed exactly."""
    p = truth["post"]
    p_hat = np.clip(p_hat, 1e-12, 1 - 1e-12)
    kl = p * np.log(p / p_hat) + (1 - p) * np.log((1 - p) / (1 - p_hat))
    return float(truth["px"] @ kl)


def learning_curves(truth, sizes, reps=400, seed=20261001):
    """Mean excess log-loss of each estimator at each training-set size."""
    rng = np.random.default_rng(seed)
    flat = truth["joint"].ravel()
    out = {name: [] for name in ESTIMATORS}
    spread = {name: [] for name in ESTIMATORS}
    for n in sizes:
        draws = rng.multinomial(n, flat, size=reps).reshape(reps, 2, 16)
        acc = {name: [] for name in ESTIMATORS}
        for d in draws:
            k_x = d[1].astype(float)
            n_x = d.sum(0).astype(float)
            for name, f in ESTIMATORS.items():
                acc[name].append(excess_log_loss(truth, f(n_x, k_x)))
        for name in ESTIMATORS:
            out[name].append(float(np.mean(acc[name])))
            spread[name].append(float(np.std(acc[name]) / math.sqrt(reps)))
    return out, spread


def asymptotic_risk(truth):
    """Excess log-loss each estimator converges to with unlimited data
    (obtained by fitting on the exact joint distribution, scaled to a huge n)."""
    big = 1e9
    k_x, n_x = truth["joint"][1] * big, truth["px"] * big
    res = {}
    for name, f in ESTIMATORS.items():
        kw = {"ridge": 0.0} if name == "pairwise" else {}
        res[name] = excess_log_loss(truth, f(n_x, k_x, **kw))
    return res
