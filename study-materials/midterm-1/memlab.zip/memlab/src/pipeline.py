"""Compute every number shown in the report.  `python run_all.py` calls build_results()."""
import csv
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path

import numpy as np

import embeddings as em
import hmm as H
import markov as mk
import memory as mem
from homework import ALPHABET, EMAILS, QUERY_B, QUERY_C, SYMBOLS, WORDS, X, Y
from markov import BOS, EOS, pad
from naive_bayes import BernoulliNB, all_states, empirical_cells

ROOT = Path(__file__).resolve().parents[1]
CORPUS = ROOT / "data" / "raw" / "synthetic_spam_nlp_samples.csv"

# Hyper-parameters are fixed in advance, not tuned on the evaluation data.
ALPHA = 0.5          # add-alpha smoothing (value used in the earlier discussion)
TAU = 10.0           # prior strength of the support-weighted interpolation (same source)
KN_DISCOUNT = 0.75   # conventional absolute discount
MAX_ORDER = 3
N_FOLDS = 5
DECAY_ALPHA = 0.1    # light smoothing for the online tracker
SIM_SIZES = [10, 20, 40, 80, 160, 320, 640, 1280, 2560, 5120, 10240, 20480]
SIM_REPS = 400

# Seeds for EM.  After training, the states no longer mean what the seeds meant, so they
# are renamed from what they actually learned (see tests/test_all.py::test_hmm_state_names).
SEED_WORDS = {
    "promo": {"miracle", "alternative", "amazing", "money", "offer", "cure", "fast"},
    "medical": {"medicine", "doctor", "injury", "foot", "cure", "treats", "helps", "needs", "recommends"},
    "sports": {"basketball", "team", "game", "score", "tonight", "foot"},
    "neutral": {"today", "please", "report", "message", "after"},
}
SEED_A = [[.58, .17, .05, .20], [.10, .58, .10, .22], [.04, .10, .66, .20], [.14, .18, .16, .52]]
STATE_ORDER = [0, 3, 1, 2]                      # display order after training
STATE_NAMES = ["促销开头", "促销收尾", "伤病医疗", "体育"]
STATE_KEYS = ["promo_open", "promo_tail", "medical", "sports"]


def fr(x):
    """Fraction -> 'a/b' string (or None)."""
    if x is None:
        return None
    x = Fraction(x)
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def load_corpus():
    with open(CORPUS, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    return [r["text"].lower().split() for r in rows], [int(r["spam"]) for r in rows]


# ---------------------------------------------------------------- problem 5
def problem5():
    nb = BernoulliNB(alpha=0, exact=True).fit(X, Y)
    cells = empirical_cells(X, Y)
    states = []
    for x in all_states(4):
        post = nb.posterior(x)
        n, k = cells.get(x, (0, 0))
        states.append({
            "x": "".join(map(str, x)),
            "w_spam": fr(nb.weight(x, 1)), "w_not": fr(nb.weight(x, 0)),
            "post": fr(post), "post_f": float(post),
            "label": int(post > Fraction(1, 2)),
            "n": n, "k": k,
            "terms": nb.log_odds_terms(x),
        })
    preds = [nb.predict(x) for x in X]
    pairs = []
    for size in (2, 3):
        for p in mem.conjunction_memory(X, Y, WORDS, size=size):
            pairs.append({"features": p["features"], "n": p["n"], "k": p["k"],
                          "mle": fr(p["mle"]), "post_mean": fr(p["post_mean"]),
                          "post_mean_f": float(p["post_mean"]),
                          "lo": p["ci95"][0], "hi": p["ci95"][1]})
    return {
        "words": list(WORDS),
        "emails": [{"spam": y, "x": list(x)} for y, x in EMAILS],
        "p_spam": [fr(p) for p in nb.p[1]], "p_not": [fr(p) for p in nb.p[0]],
        "prior_spam": fr(nb.prior[1]),
        "states": states,
        "train_correct": sum(int(p == y) for p, y in zip(preds, Y)),
        "misclassified_rows": [i + 1 for i, (p, y) in enumerate(zip(preds, Y)) if p != y],
        "observed_cells": len(cells),
        "query_b": "".join(map(str, QUERY_B)), "query_c": "".join(map(str, QUERY_C)),
        "conjunctions": pairs,
    }


# ---------------------------------------------------------------- bias-variance
def simulation():
    truth = mem.make_truth()
    curves, se = mem.learning_curves(truth, SIM_SIZES, reps=SIM_REPS)
    best = [min(curves, key=lambda m: curves[m][i]) for i in range(len(SIM_SIZES))]
    return {"sizes": SIM_SIZES, "reps": SIM_REPS, "curves": curves, "se": se,
            "params": {"p_spam": [0.8, 0.4, 0.4, 0.2], "p_not": [0.2, 0.6, 0.4, 0.8],
                       "theta_ad_spam": 2.0, "theta_db_not": 1.5, "theta_mad_spam": -2.5},
            "limits": {name: f(truth["px"] * 1e9, truth["joint"][1] * 1e9,
                               **({"ridge": 0.0} if name == "pairwise" else {})).tolist()
                       for name, f in mem.ESTIMATORS.items()},
            "asymptote": mem.asymptotic_risk(truth), "best": best,
            "truth_post": truth["post"].tolist(), "truth_px": truth["px"].tolist()}


# ---------------------------------------------------------------- problem 6
def problem6():
    seq = list(SYMBOLS)
    V = list(ALPHABET)
    t1 = mk.context_table(seq, 1)
    counts = [[t1[(a,)][b] for b in V] for a in V]
    probs = [[fr(Fraction(c, sum(row))) for c in row] for row in counts]
    contexts = {}
    for k in (1, 2, 3):
        tab = mk.context_table(seq, k)
        contexts[k] = [{"ctx": "".join(h), "counts": [c[b] for b in V], "n": sum(c.values())}
                       for h, c in sorted(tab.items(), key=lambda kv: (-sum(kv[1].values()), kv[0]))]
    runs = mk.run_lengths(seq)
    by_symbol = {s: [n for r, n in runs if r == s] for s in V}
    p_stay = {s: Fraction(counts[i][i], sum(counts[i])) for i, s in enumerate(V)}
    dagger_runs = by_symbol["†"]
    p_len3 = p_stay["†"] ** 2 * (1 - p_stay["†"])
    preq = [{"name": "均匀编码 log₂3", "group": "基线", "bits": math.log2(3)}]
    for k in range(0, 5):
        b, _ = mk.prequential_bits(seq, lambda k=k: mk.AddAlpha(V, k, ALPHA), k)
        preq.append({"name": f"{k} 阶 + add-α", "group": "固定阶数", "bits": b})
    for tau in (0.5, 2.0, TAU):
        b, _ = mk.prequential_bits(seq, lambda tau=tau: mk.SupportInterpolation(V, MAX_ORDER, tau, ALPHA), MAX_ORDER)
        preq.append({"name": f"支持度插值 τ={tau:g}", "group": "多层记忆", "bits": b})
    b, _ = mk.prequential_bits(seq, lambda: mk.KneserNey(V, MAX_ORDER, KN_DISCOUNT), MAX_ORDER)
    preq.append({"name": f"Kneser–Ney D={KN_DISCOUNT}", "group": "多层记忆", "bits": b})
    return {
        "seq": seq, "alphabet": V, "counts": counts, "probs": probs, "contexts": contexts,
        "runs": by_symbol,
        "p_stay_dagger": fr(p_stay["†"]),
        "geom_dagger": mk.geometric_run_pmf(float(p_stay["†"]), 6),
        "p_len3": fr(p_len3),
        "p_all_len3": float(p_len3 ** len(dagger_runs)),
        "n_dagger_runs": len(dagger_runs),
        "prequential": preq,
        "order_test": [mk.markov_order_test(seq, V, k1) for k1 in (2, 3)],
        "dispersion_test": mk.run_dispersion_test(seq, V, "†"),
    }


# ---------------------------------------------------------------- corpus
def grouped_folds(sents, n_folds=N_FOLDS, seed=5):
    """Folds are assigned per distinct sentence, so every test sentence is unseen in training
    (the corpus repeats 70 templates; random folds would only test memorisation)."""
    uniq = sorted({" ".join(s) for s in sents})
    perm = np.random.default_rng(seed).permutation(len(uniq))
    fold_of = {uniq[i]: j % n_folds for j, i in enumerate(perm)}
    return [fold_of[" ".join(s)] for s in sents]


def corpus_models(sents, labels):
    vocab = sorted({w for s in sents for w in s})
    V = vocab + [EOS]
    folds = grouped_folds(sents)
    padded = [pad(s) for s in sents]

    def cv_perplexity(make, K):
        lp, n = 0.0, 0
        for f in range(N_FOLDS):
            model = make().fit([p for p, g in zip(padded, folds) if g != f], first=1)
            for p in (p for p, g in zip(padded, folds) if g == f):
                for t in range(1, len(p)):
                    lp += math.log(model.prob(tuple(p[max(0, t - K):t]), p[t]))
                    n += 1
        return math.exp(-lp / n)

    lm = []
    for k in range(0, MAX_ORDER + 1):
        lm.append({"name": f"{k} 阶 + add-α", "group": "固定阶数",
                   "ppl": cv_perplexity(lambda k=k: mk.AddAlpha(V, k, ALPHA), k)})
    for tau in (0.5, 2.0, TAU):
        lm.append({"name": f"支持度插值 τ={tau:g}", "group": "多层记忆",
                   "ppl": cv_perplexity(lambda tau=tau: mk.SupportInterpolation(V, MAX_ORDER, tau, ALPHA), MAX_ORDER)})
    lm.append({"name": f"Kneser–Ney D={KN_DISCOUNT}", "group": "多层记忆",
               "ppl": cv_perplexity(lambda: mk.KneserNey(V, MAX_ORDER, KN_DISCOUNT), MAX_ORDER)})

    fail = []
    for k in (1, 2, 3):
        acc = Counter()
        for f in range(N_FOLDS):
            r = mk.mle_failures([p for p, g in zip(padded, folds) if g != f],
                                [p for p, g in zip(padded, folds) if g == f], k)
            acc["unseen"] += r["unseen_context"] * r["tokens"]
            acc["zero"] += r["zero_probability"] * r["tokens"]
            acc["n"] += r["tokens"]
        fail.append({"k": k, "unseen_context": acc["unseen"] / acc["n"],
                     "zero_probability": acc["zero"] / acc["n"]})

    chain = mk.absorbing_chain(sents)
    emp_len = float(np.mean([len(s) for s in sents]))
    word_rate = Counter(w for s in sents for w in s)
    visits = sorted(((s, float(v), word_rate[s] / len(sents))
                     for s, v in zip(chain["states"][1:], chain["expected_visits_from_bos"][1:])),
                    key=lambda r: -r[1])

    # Forgetting: a stream whose regime switches half-way (all non-spam, then all spam).
    # Tracked quantity: P_t(first word = miracle).  The <BOS> row receives exactly one count
    # per sentence, so the effective sample size is (1 - rho^t) / (1 - rho).
    stream = [s for s, y in zip(sents, labels) if y == 0] + [s for s, y in zip(sents, labels) if y == 1]
    switch = sum(1 for y in labels if y == 0)
    target = (BOS, "miracle")
    starts = [s[0] == target[1] for s in stream]
    decay = {"target": list(target), "switch": switch, "alpha": DECAY_ALPHA,
             "series": [{"rho": rho, "p": mk.decayed_tracking(stream, rho, target, DECAY_ALPHA),
                         "n_eff": None if rho == 1.0 else 1.0 / (1.0 - rho)}
                        for rho in (1.0, 0.98, 0.9)],
             "regime1_freq": sum(starts[:switch]) / switch,
             "regime2_freq": sum(starts[switch:]) / (len(stream) - switch),
             "overall_freq": sum(starts) / len(stream)}

    # Conjunction memory on the corpus (the four pairs quoted in the earlier discussion).
    Xd = [set(s) for s in sents]
    pairs = []
    for a, b in [("miracle", "medicine"), ("alternative", "medicine"),
                 ("basketball", "medicine"), ("foot", "medicine")]:
        sel = [y for d, y in zip(Xd, labels) if a in d and b in d]
        n, k = len(sel), sum(sel)
        lo, hi = mem.beta_interval(k, n)
        pairs.append({"features": [a, b], "n": n, "k": k, "post_mean": fr(mem.beta_posterior_mean(k, n)),
                      "post_mean_f": float(mem.beta_posterior_mean(k, n)), "lo": lo, "hi": hi})

    return {
        "n_docs": len(sents), "n_unique": len({" ".join(s) for s in sents}),
        "n_spam": int(sum(labels)), "vocab_size": len(vocab), "mean_len": emp_len,
        "lm": lm, "mle_fail": fail,
        "absorbing": {"expected_length": chain["expected_length"], "empirical_length": emp_len,
                      "absorption_prob": chain["absorption_prob_from_bos"],
                      "max_abs_visit_error": float(max(abs(v - e) for _, v, e in visits)),
                      "visits": [{"word": w, "model": v, "empirical": e} for w, v, e in visits]},
        "decay": decay, "pairs": pairs,
        "data": {"sents": sents, "labels": labels, "folds": folds, "vocab": vocab},
    }


# ---------------------------------------------------------------- embeddings + HMM
def train_hmm(sents, vocab):
    v2i = {w: i for i, w in enumerate(vocab)}
    pi0, A0, B0 = H.seed_parameters(vocab, SEED_WORDS, SEED_A)
    ids = [[v2i[w] for w in s] for s in sents]
    pi, A, B, trace = H.baum_welch(ids, pi0, A0, B0, iters=300)
    o = STATE_ORDER
    return pi[o], A[np.ix_(o, o)], B[o], trace


def embeddings_and_hmm(sents, labels):
    vocab = sorted({w for s in sents for w in s})
    v2i = {w: i for i, w in enumerate(vocab)}
    Xb = [[int(w in set(s)) for w in vocab] for s in sents]
    nb = BernoulliNB(alpha=1, exact=False).fit(Xb, labels)
    counts = Counter(w for s in sents for w in s)

    P = em.ppmi(em.cooccurrence(sents, v2i, window=2))
    E, S = em.svd_embeddings(P, 8)
    table = em.build_ngram_table(vocab, E)
    words = [{"w": w, "x": float(E[i, 0]), "y": float(E[i, 1]), "count": counts[w],
              "p_spam": nb.p[1][i], "p_not": nb.p[0][i],
              "log_odds": math.log(nb.p[1][i] / nb.p[0][i])} for i, w in enumerate(vocab)]

    pi, A, B, trace = train_hmm(sents, vocab)
    emit = H.OOVEmission(vocab, B, E, table, temp=10.0)
    examples = []
    for text in ["miracle xyzzy cure", "doctor recommends medicinal cure",
                 "miracle experimental medicine near basketball", "basketball xyzzy medicine"]:
        toks = text.split()
        for mode in ("flat", "subword"):
            L, info = emit.matrix(toks, mode)
            g, _, ll = H.forward_backward(pi, A, L)
            examples.append({"text": text, "mode": mode, "gamma": g.tolist(),
                             "viterbi": H.viterbi(pi, A, L), "oov": [i["oov"] for i in info]})
    # Keeping the unknown token's slot versus deleting it: one more transition is taken.
    kd_text = "miracle xyzzy cure"
    toks = kd_text.split()
    Lk, _ = emit.matrix(toks, "flat")
    Ld, _ = emit.matrix([t for t in toks if t in v2i], "flat")
    keep = H.forward_backward(pi, A, Lk)[0][-1]
    drop = H.forward_backward(pi, A, Ld)[0][-1]

    same_word = []
    for text in ("miracle medicine", "doctor recommends medicine"):
        toks = text.split()
        g = H.forward_backward(pi, A, emit.matrix(toks, "flat")[0])[0][toks.index("medicine")]
        same_word.append({"text": text, "argmax": int(g.argmax()), "p": float(g.max())})

    return {
        "emb": {"words": words, "singular_values": S[:8].tolist(), "window": 2, "dim": 8},
        "hmm": {
            "states": STATE_NAMES, "state_keys": STATE_KEYS, "vocab": vocab,
            "pi": pi.tolist(), "A": A.tolist(), "B": B.tolist(),
            "top_words": [[{"w": vocab[i], "p": float(B[k, i])} for i in np.argsort(-B[k])[:6]]
                          for k in range(len(STATE_NAMES))],
            "E": np.round(E, 6).tolist(),
            "ngrams": {g: np.round(v, 6).tolist() for g, v in sorted(table.items())},
            "temp": 10.0, "em_iters": len(trace), "objective_start": trace[0], "objective_end": trace[-1],
            "examples": examples,
            "same_word": same_word,
            "keep_vs_drop": {"text": kd_text, "keep": keep.tolist(), "drop": drop.tolist()},
        },
    }


def code_snippets():
    """Source of the core routines, shown verbatim in the report."""
    import inspect
    import textwrap
    import naive_bayes
    items = [
        ("朴素贝叶斯：权重与后验", "src/naive_bayes.py", [naive_bayes.BernoulliNB.weight, naive_bayes.BernoulliNB.posterior]),
        ("支持度插值：证据越多越信长上下文", "src/markov.py", [mk.SupportInterpolation.prob]),
        ("Kneser–Ney 递归", "src/markov.py", [mk.KneserNey._p]),
        ("HMM forward–backward（带缩放）", "src/hmm.py", [H.forward_backward]),
        ("OOV 的发射似然", "src/hmm.py", [H.OOVEmission.likelihood]),
    ]
    return [{"title": t, "file": f, "src": "\n".join(textwrap.dedent(inspect.getsource(o)) for o in objs)}
            for t, f, objs in items]


def build_results():
    sents, labels = load_corpus()
    out = {"hw5": problem5(), "sim": simulation(), "hw6": problem6(),
           "corpus": corpus_models(sents, labels)}
    out.update(embeddings_and_hmm(sents, labels))
    out["code"] = code_snippets()
    out["params"] = {"alpha": ALPHA, "tau": TAU, "kn_discount": KN_DISCOUNT,
                     "max_order": MAX_ORDER, "folds": N_FOLDS}
    return out
