"""Discrete hidden Markov model: scaled forward-backward, Viterbi, Baum-Welch (MAP-EM),
and an emission rule that keeps out-of-vocabulary tokens in place."""
from itertools import product
import numpy as np

from embeddings import oov_embedding, cosine_to_vocab


def forward_backward(pi, A, L):
    """L[t, k] = likelihood of the observation at position t under state k.

    Returns gamma[t, k] = P(Z_t = k | all observations), the summed pairwise posteriors
    xi[i, j] = sum_t P(Z_t = i, Z_{t+1} = j | obs), and the log-likelihood."""
    T, K = L.shape
    alpha, scale = np.zeros((T, K)), np.zeros(T)
    alpha[0] = pi * L[0]
    scale[0] = alpha[0].sum()
    alpha[0] /= scale[0]
    for t in range(1, T):
        alpha[t] = (alpha[t - 1] @ A) * L[t]
        scale[t] = alpha[t].sum()
        alpha[t] /= scale[t]
    beta = np.ones((T, K))
    for t in range(T - 2, -1, -1):
        beta[t] = A @ (L[t + 1] * beta[t + 1]) / scale[t + 1]
    gamma = alpha * beta
    xi = np.zeros((K, K))
    for t in range(T - 1):
        xi += alpha[t][:, None] * A * (L[t + 1] * beta[t + 1])[None, :] / scale[t + 1]
    return gamma, xi, float(np.log(scale).sum())


def viterbi(pi, A, L):
    T, K = L.shape
    with np.errstate(divide="ignore"):
        lp, lA, lL = np.log(pi), np.log(A), np.log(L)
    delta = lp + lL[0]
    back = np.zeros((T, K), dtype=int)
    for t in range(1, T):
        cand = delta[:, None] + lA
        back[t] = cand.argmax(0)
        delta = cand.max(0) + lL[t]
    path = [int(delta.argmax())]
    for t in range(T - 1, 0, -1):
        path.append(int(back[t, path[-1]]))
    return path[::-1]


def brute_force_gamma(pi, A, L):
    """Posterior marginals by summing over all K^T state paths (for testing only)."""
    T, K = L.shape
    gamma, total = np.zeros((T, K)), 0.0
    for z in product(range(K), repeat=T):
        p = pi[z[0]] * L[0, z[0]]
        for t in range(1, T):
            p *= A[z[t - 1], z[t]] * L[t, z[t]]
        total += p
        for t, k in enumerate(z):
            gamma[t, k] += p
    return gamma / total, float(np.log(total))


def seed_parameters(vocab, lexical, A0, boost=8.0):
    """Starting point for EM: emissions boosted on a few seed words per state."""
    K = len(lexical)
    B = np.ones((K, len(vocab)))
    for k, words in enumerate(lexical.values()):
        for w in words:
            if w in vocab:
                B[k, vocab.index(w)] += boost
    B /= B.sum(1, keepdims=True)
    return np.full(K, 1.0 / K), np.array(A0, dtype=float), B


def baum_welch(seqs, pi, A, B, iters=200, a=0.1, b=0.01, tol=1e-9):
    """MAP-EM with pseudo-counts a (initial/transition) and b (emission).

    seqs: lists of vocabulary ids.  Returns the fitted parameters and the trace of the
    penalised objective  log P(data) + a*sum(log pi) + a*sum(log A) + b*sum(log B),
    which EM never decreases."""
    pi, A, B = pi.copy(), A.copy(), B.copy()
    K, V = B.shape
    trace = []
    for _ in range(iters):
        pi_acc, A_acc, B_acc, ll = np.zeros(K), np.zeros((K, K)), np.zeros((K, V)), 0.0
        for ids in seqs:
            gamma, xi, l = forward_backward(pi, A, B[:, ids].T)
            ll += l
            pi_acc += gamma[0]
            A_acc += xi
            np.add.at(B_acc.T, ids, gamma)
        trace.append(ll + a * np.log(pi).sum() + a * np.log(A).sum() + b * np.log(B).sum())
        pi = (pi_acc + a) / (pi_acc + a).sum()
        A = (A_acc + a) / (A_acc + a).sum(1, keepdims=True)
        B = (B_acc + b) / (B_acc + b).sum(1, keepdims=True)
        if len(trace) > 1 and trace[-1] - trace[-2] < tol:
            break
    return pi, A, B, trace


class OOVEmission:
    """Likelihood vector for every token, known or not.

    known word v           -> B[:, v]
    OOV, mode "flat"       -> all ones: the position is kept, its identity carries no evidence,
                              so the state posterior there comes from the neighbours alone.
    OOV, mode "subword"    -> (1 - s) * flat + s * sum_v K(w, v) B[:, v], where
                              K = softmax(temp * cosine(e(w), e(v))) over the vocabulary,
                              e(w) is the character n-gram vector and s is the share of the
                              word's n-grams that are known (s = 0 falls back to flat)."""

    def __init__(self, vocab, B, E, ngram_table, temp=10.0):
        self.vocab, self.B, self.E, self.table, self.temp = list(vocab), B, E, ngram_table, temp
        self.v2i = {w: i for i, w in enumerate(self.vocab)}

    def kernel(self, word):
        e, s = oov_embedding(word, self.table, self.E.shape[1])
        if s == 0:
            return None, 0.0
        z = self.temp * cosine_to_vocab(e, self.E)
        k = np.exp(z - z.max())
        return k / k.sum(), s

    def likelihood(self, word, mode="subword"):
        if word in self.v2i:
            return self.B[:, self.v2i[word]].copy(), {"oov": False}
        K = self.B.shape[0]
        info = {"oov": True, "coverage": 0.0, "nearest": []}
        if mode == "flat":
            return np.ones(K), info
        kern, s = self.kernel(word)
        if kern is None:
            return np.ones(K), info
        shaped = self.B @ kern
        top = np.argsort(-kern)[:3]
        info.update(coverage=s, nearest=[(self.vocab[i], float(kern[i])) for i in top])
        return (1 - s) * shaped.mean() + s * shaped, info

    def matrix(self, tokens, mode="subword"):
        rows, infos = zip(*(self.likelihood(w, mode) for w in tokens))
        return np.vstack(rows), list(infos)
