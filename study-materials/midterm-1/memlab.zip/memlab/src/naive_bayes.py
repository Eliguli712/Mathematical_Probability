"""Bernoulli naive Bayes with exact (Fraction) or float arithmetic."""
from fractions import Fraction
from itertools import product
import math


class BernoulliNB:
    """P(y) * prod_j p_{j,y}^{x_j} (1 - p_{j,y})^{1 - x_j}.

    alpha = 0 gives the maximum-likelihood estimate used in the homework;
    alpha > 0 puts a Beta(alpha, alpha) pseudo-count on every Bernoulli parameter.
    """

    def __init__(self, alpha=0, exact=True):
        self.alpha = alpha
        self.exact = exact

    def _ratio(self, a, b):
        return Fraction(a) / Fraction(b) if self.exact else float(a) / float(b)

    def fit(self, X, y):
        X = [tuple(r) for r in X]
        self.d = len(X[0])
        n = len(y)
        a = self.alpha
        self.n_class = {c: sum(1 for t in y if t == c) for c in (0, 1)}
        self.prior = {c: self._ratio(self.n_class[c] + a, n + 2 * a) for c in (0, 1)}
        self.p = {
            c: [
                self._ratio(sum(r[j] for r, t in zip(X, y) if t == c) + a,
                            self.n_class[c] + 2 * a)
                for j in range(self.d)
            ]
            for c in (0, 1)
        }
        return self

    def weight(self, x, c):
        """Unnormalised posterior weight w_c(x) = P(c) prod_j P(x_j | c)."""
        w = self.prior[c]
        for xj, pj in zip(x, self.p[c]):
            w = w * (pj if xj else 1 - pj)
        return w

    def posterior(self, x):
        """P(spam | x); None when both weights vanish (0/0)."""
        ws, wn = self.weight(x, 1), self.weight(x, 0)
        return None if ws + wn == 0 else ws / (ws + wn)

    def predict(self, x):
        return int(self.weight(x, 1) > self.weight(x, 0))

    def log_odds_terms(self, x):
        """Additive evidence: [prior term, term for feature 1, ..., feature d].

        Their sum is log P(S|x) / P(N|x).
        """
        def lr(a, b):
            if a == 0 and b == 0:
                return float("nan")
            if a == 0:
                return -math.inf
            if b == 0:
                return math.inf
            return math.log(float(a) / float(b))

        terms = [lr(self.prior[1], self.prior[0])]
        for j, xj in enumerate(x):
            ps, pn = self.p[1][j], self.p[0][j]
            terms.append(lr(ps, pn) if xj else lr(1 - ps, 1 - pn))
        return terms


def all_states(d):
    return list(product((0, 1), repeat=d))


def empirical_cells(X, y):
    """Counts for the saturated table: state -> (n_x, spam count k_x)."""
    cells = {}
    for r, t in zip(X, y):
        n, k = cells.get(tuple(r), (0, 0))
        cells[tuple(r)] = (n + 1, k + t)
    return cells
