"""Distributional word vectors from the corpus itself (PPMI + truncated SVD) and
character n-gram vectors for words that are not in the vocabulary."""
from collections import defaultdict
import numpy as np


def cooccurrence(sentences, v2i, window=2):
    C = np.zeros((len(v2i), len(v2i)))
    for s in sentences:
        ids = [v2i[w] for w in s if w in v2i]
        for i, wi in enumerate(ids):
            for j in range(max(0, i - window), min(len(ids), i + window + 1)):
                if i != j:
                    C[wi, ids[j]] += 1
    return C


def ppmi(C):
    total = C.sum()
    row, col = C.sum(1, keepdims=True), C.sum(0, keepdims=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        pmi = np.log(C * total / (row @ col))
    return np.where(np.isfinite(pmi) & (pmi > 0), pmi, 0.0)


def svd_embeddings(M, dim):
    """E = U_d * sqrt(S_d).  Column signs are fixed (largest-magnitude entry positive)
    so the result is reproducible across LAPACK builds."""
    U, S, _ = np.linalg.svd(M, full_matrices=False)
    d = min(dim, U.shape[1])
    E = U[:, :d] * np.sqrt(S[:d])
    for j in range(d):
        if E[np.argmax(np.abs(E[:, j])), j] < 0:
            E[:, j] *= -1
    return E, S


def char_ngrams(word, lo=3, hi=5):
    s = "<" + word + ">"
    return [s[i:i + n] for n in range(lo, hi + 1) for i in range(max(0, len(s) - n + 1))]


def build_ngram_table(vocab, E):
    """Vector of an n-gram = mean vector of the vocabulary words containing it."""
    table = defaultdict(list)
    for w, e in zip(vocab, E):
        for g in set(char_ngrams(w)):
            table[g].append(e)
    return {g: np.mean(v, axis=0) for g, v in table.items()}


def oov_embedding(word, table, dim):
    """Mean of the known n-gram vectors, and the share of the word's n-grams that were known."""
    grams = char_ngrams(word)
    hit = [table[g] for g in grams if g in table]
    if not hit:
        return np.zeros(dim), 0.0
    return np.mean(hit, axis=0), len(hit) / len(grams)


def cosine_to_vocab(e, E):
    den = np.linalg.norm(E, axis=1) * np.linalg.norm(e)
    with np.errstate(divide="ignore", invalid="ignore"):
        c = (E @ e) / den
    return np.where(np.isfinite(c), c, 0.0)
