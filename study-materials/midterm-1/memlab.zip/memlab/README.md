# 记忆惯性实验（memlab）

第 5 题（垃圾邮件朴素贝叶斯）、第 6 题（符号序列的马尔可夫链）以及后续讨论里的
组合记忆、n-gram 回退、吸收链、衰减计数、词向量、OOV + HMM 的完整实现。

## English / Deutsch report

Open `outputs/report.html` and use the language control in the upper-right corner
to switch the complete interface between English and German. The report remains
a single offline HTML file. `run_all.py` inlines `viz/i18n.js`, so regenerated
reports preserve the same language switch.

Öffnen Sie `outputs/report.html` und verwenden Sie die Sprachwahl oben rechts,
um die gesamte Oberfläche zwischen Englisch und Deutsch umzuschalten. Der
Bericht bleibt eine einzelne, offline nutzbare HTML-Datei. `run_all.py` bindet
`viz/i18n.js` ein, sodass auch neu erzeugte Berichte dieselbe Sprachwahl
beibehalten.

## 运行

```bash
pip install -r requirements.txt     # 只依赖 numpy
python run_all.py                    # 重算全部数字，写出 outputs/
python tests/run_tests.py            # 25 项检查；也可以用 pytest -q
```

`run_all.py` 约 30 秒，产出：

| 文件 | 内容 |
|---|---|
| `outputs/report.html` | 自包含的交互式页面，双击即可在浏览器打开；训练表、符号序列、平滑参数和模拟设定都能改，图表在浏览器里实时重算 |
| `outputs/results.json` | 页面用到的全部数字 |
| `outputs/tables/*.csv` | 10 张表：16 种输入的后验、组合记忆、转移矩阵、学习曲线、困惑度、HMM 参数等 |

## 目录

```
src/homework.py      题目数据：10 封邮件的表、37 个符号的序列
src/naive_bayes.py   伯努利朴素贝叶斯，支持精确分数运算
src/memory.py        Beta 后验与可信区间；组合记忆；三种估计的偏差–方差模拟
src/markov.py        n-gram 计数、add-α、支持度插值、Kneser–Ney、吸收链、衰减计数
src/embeddings.py    PPMI + SVD 词向量；字符 n-gram 的 OOV 向量
src/hmm.py           forward–backward、Viterbi、Baum–Welch、OOV 发射似然
src/pipeline.py      把上面的模块串起来，算出页面上的每一个数
viz/template.html    页面模板，run_all.py 把 results.json 注入其中
tests/test_all.py    对照手写答案、闭式解和暴力枚举的检查
data/raw/            原 ZIP 里的 160 条合成语料（未改动）
```

## 数据来源

- **第 5、6 题**：从题目图片转录，写在 `src/homework.py`。第 6 题的符号行有几处被圈画盖住，
  采用的读法能精确复现手写的转移矩阵 (0, 4/7, 3/7)、(4/11, 4/11, 3/11)、(1/6, 1/6, 2/3)。
- **160 条语料**：原 ZIP 的 `synthetic_spam_nlp_samples.csv`，由 70 个模板句重复而成。
- **偏差–方差模拟**：生成分布是为实验设定的（`memory.make_truth`），不是题目数据。

## 相对原 ZIP 的改动

- 第 5、6 题改用题目的真实数据，并用 `fractions.Fraction` 给出精确分数。
- HMM 的参数原来是手填的，现在用 Baum–Welch 训练。原来的 forward–backward 后验是对的
  （与枚举全部状态路径相差 1e-15），这里补上了 ξ、对数似然、Viterbi，并把枚举对照写进测试。
- 词表外的词除了保留位置，还可以用字符 n-gram 的相似度给出发射似然，并与“直接删除”对比。
- 新增支持度插值、Kneser–Ney、吸收链、分组交叉验证和偏差–方差模拟。
- 测试从 8 项形状检查改为 25 项数值检查。
- 第 6 题新增一阶假设的自助检验：游程离散度检验和 1 阶对 2、3 阶的似然比检验。
- 平滑参数 α = 0.5、τ = 10、Kneser–Ney 折扣 0.75 事先固定，没有在评测数据上调。

## 页面里的实时计算

`viz/template.html` 用 JavaScript 重写了同一套算法（朴素贝叶斯的精确分数、Beta 分位数、
三种估计的模拟、add-α / 支持度插值 / Kneser–Ney、自助检验、衰减计数、forward–backward、Viterbi）。
默认参数下它们与 Python 结果逐项对照过：确定性的量相差不超过 1e-7，
模拟曲线在蒙特卡洛误差之内。页面上的文字结论针对题目原始数据和默认参数。
